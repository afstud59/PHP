<?php
require_once(getabspath("classes/cipherer.php"));




$tdataDeductions_Archive_Report = array();	
	$tdataDeductions_Archive_Report[".truncateText"] = true;
	$tdataDeductions_Archive_Report[".NumberOfChars"] = 80; 
	$tdataDeductions_Archive_Report[".ShortName"] = "Deductions_Archive_Report";
	$tdataDeductions_Archive_Report[".OwnerID"] = "";
	$tdataDeductions_Archive_Report[".OriginalTable"] = "deductionsarchive";

//	field labels
$fieldLabelsDeductions_Archive_Report = array();
$fieldToolTipsDeductions_Archive_Report = array();
$pageTitlesDeductions_Archive_Report = array();

if(mlang_getcurrentlang()=="English")
{
	$fieldLabelsDeductions_Archive_Report["English"] = array();
	$fieldToolTipsDeductions_Archive_Report["English"] = array();
	$pageTitlesDeductions_Archive_Report["English"] = array();
	$fieldLabelsDeductions_Archive_Report["English"]["date"] = "Date";
	$fieldToolTipsDeductions_Archive_Report["English"]["date"] = "";
	$fieldLabelsDeductions_Archive_Report["English"]["branch"] = "Branch";
	$fieldToolTipsDeductions_Archive_Report["English"]["branch"] = "";
	$fieldLabelsDeductions_Archive_Report["English"]["employeeidnumber"] = "Employee ID Number";
	$fieldToolTipsDeductions_Archive_Report["English"]["employeeidnumber"] = "";
	$fieldLabelsDeductions_Archive_Report["English"]["employeename"] = "Employee Name";
	$fieldToolTipsDeductions_Archive_Report["English"]["employeename"] = "";
	$fieldLabelsDeductions_Archive_Report["English"]["deductionamount"] = "Deduction Amount";
	$fieldToolTipsDeductions_Archive_Report["English"]["deductionamount"] = "";
	$fieldLabelsDeductions_Archive_Report["English"]["deductionreason"] = "Deduction Reason";
	$fieldToolTipsDeductions_Archive_Report["English"]["deductionreason"] = "";
	$fieldLabelsDeductions_Archive_Report["English"]["duration"] = "Duration";
	$fieldToolTipsDeductions_Archive_Report["English"]["duration"] = "";
	if (count($fieldToolTipsDeductions_Archive_Report["English"]))
		$tdataDeductions_Archive_Report[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="")
{
	$fieldLabelsDeductions_Archive_Report[""] = array();
	$fieldToolTipsDeductions_Archive_Report[""] = array();
	$pageTitlesDeductions_Archive_Report[""] = array();
	if (count($fieldToolTipsDeductions_Archive_Report[""]))
		$tdataDeductions_Archive_Report[".isUseToolTips"] = true;
}
	
	
	$tdataDeductions_Archive_Report[".NCSearch"] = true;



$tdataDeductions_Archive_Report[".shortTableName"] = "Deductions_Archive_Report";
$tdataDeductions_Archive_Report[".nSecOptions"] = 0;
$tdataDeductions_Archive_Report[".recsPerRowList"] = 1;
$tdataDeductions_Archive_Report[".recsPerRowPrint"] = 1;
$tdataDeductions_Archive_Report[".mainTableOwnerID"] = "";
$tdataDeductions_Archive_Report[".moveNext"] = 1;
$tdataDeductions_Archive_Report[".entityType"] = 2;

$tdataDeductions_Archive_Report[".strOriginalTableName"] = "deductionsarchive";




$tdataDeductions_Archive_Report[".showAddInPopup"] = false;

$tdataDeductions_Archive_Report[".showEditInPopup"] = false;

$tdataDeductions_Archive_Report[".showViewInPopup"] = false;

//page's base css files names
$popupPagesLayoutNames = array();
$tdataDeductions_Archive_Report[".popupPagesLayoutNames"] = $popupPagesLayoutNames;


$tdataDeductions_Archive_Report[".fieldsForRegister"] = array();

$tdataDeductions_Archive_Report[".listAjax"] = false;

	$tdataDeductions_Archive_Report[".audit"] = false;

	$tdataDeductions_Archive_Report[".locking"] = false;


$tdataDeductions_Archive_Report[".add"] = true;
$tdataDeductions_Archive_Report[".afterAddAction"] = 1;
$tdataDeductions_Archive_Report[".closePopupAfterAdd"] = 1;
$tdataDeductions_Archive_Report[".afterAddActionDetTable"] = "";

$tdataDeductions_Archive_Report[".list"] = true;

$tdataDeductions_Archive_Report[".inlineAdd"] = true;


$tdataDeductions_Archive_Report[".exportTo"] = true;

$tdataDeductions_Archive_Report[".printFriendly"] = true;


$tdataDeductions_Archive_Report[".showSimpleSearchOptions"] = false;

// search Saving settings
$tdataDeductions_Archive_Report[".searchSaving"] = false;
//

$tdataDeductions_Archive_Report[".showSearchPanel"] = true;
		$tdataDeductions_Archive_Report[".flexibleSearch"] = true;		

if (isMobile())
	$tdataDeductions_Archive_Report[".isUseAjaxSuggest"] = false;
else 
	$tdataDeductions_Archive_Report[".isUseAjaxSuggest"] = true;




$tdataDeductions_Archive_Report[".addPageEvents"] = false;

// use timepicker for search panel
$tdataDeductions_Archive_Report[".isUseTimeForSearch"] = false;





$tdataDeductions_Archive_Report[".allSearchFields"] = array();
$tdataDeductions_Archive_Report[".filterFields"] = array();
$tdataDeductions_Archive_Report[".requiredSearchFields"] = array();

$tdataDeductions_Archive_Report[".allSearchFields"][] = "date";
	$tdataDeductions_Archive_Report[".allSearchFields"][] = "branch";
	$tdataDeductions_Archive_Report[".allSearchFields"][] = "employeeidnumber";
	$tdataDeductions_Archive_Report[".allSearchFields"][] = "employeename";
	$tdataDeductions_Archive_Report[".allSearchFields"][] = "deductionamount";
	$tdataDeductions_Archive_Report[".allSearchFields"][] = "deductionreason";
	$tdataDeductions_Archive_Report[".allSearchFields"][] = "duration";
	
$tdataDeductions_Archive_Report[".filterFields"][] = "date";	
$tdataDeductions_Archive_Report[".filterFields"][] = "branch";	

$tdataDeductions_Archive_Report[".googleLikeFields"] = array();
$tdataDeductions_Archive_Report[".googleLikeFields"][] = "date";
$tdataDeductions_Archive_Report[".googleLikeFields"][] = "branch";
$tdataDeductions_Archive_Report[".googleLikeFields"][] = "employeeidnumber";
$tdataDeductions_Archive_Report[".googleLikeFields"][] = "employeename";
$tdataDeductions_Archive_Report[".googleLikeFields"][] = "deductionamount";
$tdataDeductions_Archive_Report[".googleLikeFields"][] = "deductionreason";
$tdataDeductions_Archive_Report[".googleLikeFields"][] = "duration";

$tdataDeductions_Archive_Report[".panelSearchFields"] = array();
$tdataDeductions_Archive_Report[".searchPanelOptions"] = array();
$tdataDeductions_Archive_Report[".panelSearchFields"][] = "date";
	$tdataDeductions_Archive_Report[".panelSearchFields"][] = "branch";
	$tdataDeductions_Archive_Report[".panelSearchFields"][] = "employeeidnumber";
	$tdataDeductions_Archive_Report[".panelSearchFields"][] = "employeename";
	$tdataDeductions_Archive_Report[".panelSearchFields"][] = "deductionamount";
	$tdataDeductions_Archive_Report[".panelSearchFields"][] = "deductionreason";
	
$tdataDeductions_Archive_Report[".advSearchFields"] = array();
$tdataDeductions_Archive_Report[".advSearchFields"][] = "date";
$tdataDeductions_Archive_Report[".advSearchFields"][] = "branch";
$tdataDeductions_Archive_Report[".advSearchFields"][] = "employeeidnumber";
$tdataDeductions_Archive_Report[".advSearchFields"][] = "employeename";
$tdataDeductions_Archive_Report[".advSearchFields"][] = "deductionamount";
$tdataDeductions_Archive_Report[".advSearchFields"][] = "deductionreason";
$tdataDeductions_Archive_Report[".advSearchFields"][] = "duration";

$tdataDeductions_Archive_Report[".tableType"] = "report";

$tdataDeductions_Archive_Report[".printerPageOrientation"] = 0;
$tdataDeductions_Archive_Report[".nPrinterPageScale"] = 100;

$tdataDeductions_Archive_Report[".nPrinterSplitRecords"] = 40;

$tdataDeductions_Archive_Report[".nPrinterPDFSplitRecords"] = 40;



$tdataDeductions_Archive_Report[".geocodingEnabled"] = false;

//report settings
$tdataDeductions_Archive_Report[".printReportLayout"] = 6;	

$tdataDeductions_Archive_Report[".reportPrintPartitionType"] = 1;	
$tdataDeductions_Archive_Report[".reportPrintGroupsPerPage"] = 40;	
	$tdataDeductions_Archive_Report[".reportPrintPDFGroupsPerPage"] = 40;
$tdataDeductions_Archive_Report[".lowGroup"] = 0;



$tdataDeductions_Archive_Report[".pageSize"] = 50;	






$tdataDeductions_Archive_Report[".repShowDet"] = true;

$tdataDeductions_Archive_Report[".reportLayout"] = 6;

//end of report settings



	





// view page pdf

// print page pdf



$tstrOrderBy = "ORDER BY deductionreason, employeeidnumber";
if(strlen($tstrOrderBy) && strtolower(substr($tstrOrderBy,0,8))!="order by")
	$tstrOrderBy = "order by ".$tstrOrderBy;
$tdataDeductions_Archive_Report[".strOrderBy"] = $tstrOrderBy;

$tdataDeductions_Archive_Report[".orderindexes"] = array();
$tdataDeductions_Archive_Report[".orderindexes"][] = array(6, (1 ? "ASC" : "DESC"), "deductionreason");
$tdataDeductions_Archive_Report[".orderindexes"][] = array(3, (1 ? "ASC" : "DESC"), "employeeidnumber");

$tdataDeductions_Archive_Report[".sqlHead"] = "SELECT `date`,  branch,  employeeidnumber,  employeename,  deductionamount,  deductionreason,  duration";
$tdataDeductions_Archive_Report[".sqlFrom"] = "FROM deductionsarchive";
$tdataDeductions_Archive_Report[".sqlWhereExpr"] = "";
$tdataDeductions_Archive_Report[".sqlTail"] = "";









//fill array of records per page for list and report without group fields
$arrRPP = array();
$arrRPP[] = 10;
$arrRPP[] = 20;
$arrRPP[] = 30;
$arrRPP[] = 50;
$arrRPP[] = 100;
$arrRPP[] = 500;
$arrRPP[] = -1;
$tdataDeductions_Archive_Report[".arrRecsPerPage"] = $arrRPP;

//fill array of groups per page for report with group fields
$arrGPP = array();
$arrGPP[] = 1;
$arrGPP[] = 3;
$arrGPP[] = 5;
$arrGPP[] = 10;
$arrGPP[] = 50;
$arrGPP[] = 100;
$arrGPP[] = -1;
$tdataDeductions_Archive_Report[".arrGroupsPerPage"] = $arrGPP;

$tdataDeductions_Archive_Report[".highlightSearchResults"] = true;

$tableKeysDeductions_Archive_Report = array();
$tdataDeductions_Archive_Report[".Keys"] = $tableKeysDeductions_Archive_Report;

$tdataDeductions_Archive_Report[".listFields"] = array();
$tdataDeductions_Archive_Report[".listFields"][] = "date";
$tdataDeductions_Archive_Report[".listFields"][] = "branch";
$tdataDeductions_Archive_Report[".listFields"][] = "employeeidnumber";
$tdataDeductions_Archive_Report[".listFields"][] = "employeename";
$tdataDeductions_Archive_Report[".listFields"][] = "deductionamount";
$tdataDeductions_Archive_Report[".listFields"][] = "deductionreason";
$tdataDeductions_Archive_Report[".listFields"][] = "duration";

$tdataDeductions_Archive_Report[".hideMobileList"] = array();


$tdataDeductions_Archive_Report[".viewFields"] = array();
$tdataDeductions_Archive_Report[".viewFields"][] = "date";
$tdataDeductions_Archive_Report[".viewFields"][] = "branch";
$tdataDeductions_Archive_Report[".viewFields"][] = "employeeidnumber";
$tdataDeductions_Archive_Report[".viewFields"][] = "employeename";
$tdataDeductions_Archive_Report[".viewFields"][] = "deductionamount";
$tdataDeductions_Archive_Report[".viewFields"][] = "deductionreason";
$tdataDeductions_Archive_Report[".viewFields"][] = "duration";

$tdataDeductions_Archive_Report[".addFields"] = array();
$tdataDeductions_Archive_Report[".addFields"][] = "date";
$tdataDeductions_Archive_Report[".addFields"][] = "branch";
$tdataDeductions_Archive_Report[".addFields"][] = "employeeidnumber";
$tdataDeductions_Archive_Report[".addFields"][] = "employeename";
$tdataDeductions_Archive_Report[".addFields"][] = "deductionamount";
$tdataDeductions_Archive_Report[".addFields"][] = "deductionreason";
$tdataDeductions_Archive_Report[".addFields"][] = "duration";

$tdataDeductions_Archive_Report[".masterListFields"] = array();
$tdataDeductions_Archive_Report[".masterListFields"][] = "date";
$tdataDeductions_Archive_Report[".masterListFields"][] = "branch";
$tdataDeductions_Archive_Report[".masterListFields"][] = "employeeidnumber";
$tdataDeductions_Archive_Report[".masterListFields"][] = "employeename";
$tdataDeductions_Archive_Report[".masterListFields"][] = "deductionamount";
$tdataDeductions_Archive_Report[".masterListFields"][] = "deductionreason";
$tdataDeductions_Archive_Report[".masterListFields"][] = "duration";

$tdataDeductions_Archive_Report[".inlineAddFields"] = array();
$tdataDeductions_Archive_Report[".inlineAddFields"][] = "date";
$tdataDeductions_Archive_Report[".inlineAddFields"][] = "branch";
$tdataDeductions_Archive_Report[".inlineAddFields"][] = "employeeidnumber";
$tdataDeductions_Archive_Report[".inlineAddFields"][] = "employeename";
$tdataDeductions_Archive_Report[".inlineAddFields"][] = "deductionamount";
$tdataDeductions_Archive_Report[".inlineAddFields"][] = "deductionreason";
$tdataDeductions_Archive_Report[".inlineAddFields"][] = "duration";

$tdataDeductions_Archive_Report[".editFields"] = array();
$tdataDeductions_Archive_Report[".editFields"][] = "date";
$tdataDeductions_Archive_Report[".editFields"][] = "branch";
$tdataDeductions_Archive_Report[".editFields"][] = "employeeidnumber";
$tdataDeductions_Archive_Report[".editFields"][] = "employeename";
$tdataDeductions_Archive_Report[".editFields"][] = "deductionamount";
$tdataDeductions_Archive_Report[".editFields"][] = "deductionreason";
$tdataDeductions_Archive_Report[".editFields"][] = "duration";

$tdataDeductions_Archive_Report[".inlineEditFields"] = array();
$tdataDeductions_Archive_Report[".inlineEditFields"][] = "date";
$tdataDeductions_Archive_Report[".inlineEditFields"][] = "branch";
$tdataDeductions_Archive_Report[".inlineEditFields"][] = "employeeidnumber";
$tdataDeductions_Archive_Report[".inlineEditFields"][] = "employeename";
$tdataDeductions_Archive_Report[".inlineEditFields"][] = "deductionamount";
$tdataDeductions_Archive_Report[".inlineEditFields"][] = "deductionreason";
$tdataDeductions_Archive_Report[".inlineEditFields"][] = "duration";

$tdataDeductions_Archive_Report[".exportFields"] = array();
$tdataDeductions_Archive_Report[".exportFields"][] = "date";
$tdataDeductions_Archive_Report[".exportFields"][] = "branch";
$tdataDeductions_Archive_Report[".exportFields"][] = "employeeidnumber";
$tdataDeductions_Archive_Report[".exportFields"][] = "employeename";
$tdataDeductions_Archive_Report[".exportFields"][] = "deductionamount";
$tdataDeductions_Archive_Report[".exportFields"][] = "deductionreason";
$tdataDeductions_Archive_Report[".exportFields"][] = "duration";

$tdataDeductions_Archive_Report[".importFields"] = array();
$tdataDeductions_Archive_Report[".importFields"][] = "date";
$tdataDeductions_Archive_Report[".importFields"][] = "branch";
$tdataDeductions_Archive_Report[".importFields"][] = "employeeidnumber";
$tdataDeductions_Archive_Report[".importFields"][] = "employeename";
$tdataDeductions_Archive_Report[".importFields"][] = "deductionamount";
$tdataDeductions_Archive_Report[".importFields"][] = "deductionreason";
$tdataDeductions_Archive_Report[".importFields"][] = "duration";

$tdataDeductions_Archive_Report[".printFields"] = array();
$tdataDeductions_Archive_Report[".printFields"][] = "date";
$tdataDeductions_Archive_Report[".printFields"][] = "branch";
$tdataDeductions_Archive_Report[".printFields"][] = "employeeidnumber";
$tdataDeductions_Archive_Report[".printFields"][] = "employeename";
$tdataDeductions_Archive_Report[".printFields"][] = "deductionamount";
$tdataDeductions_Archive_Report[".printFields"][] = "deductionreason";
$tdataDeductions_Archive_Report[".printFields"][] = "duration";

//	date
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 1;
	$fdata["strName"] = "date";
	$fdata["GoodName"] = "date";
	$fdata["ownerTable"] = "deductionsarchive";
	$fdata["Label"] = GetFieldLabel("Deductions_Archive_Report","date"); 
	$fdata["FieldType"] = 7;
	
		// report field settings
					// end of report field settings
	
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		$fdata["bInlineAdd"] = true; 
	
		$fdata["bEditPage"] = true; 
	
		$fdata["bInlineEdit"] = true; 
	
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "date"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "`date`";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "Short Date");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["report"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Date");
	
			
	
	


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		$edata["DateEditType"] = 13; 
	$edata["InitialYearFactor"] = 100; 
	$edata["LastYearFactor"] = 10; 
	
		
		
		
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
		
		
	
		
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		$fdata["defaultSearchOption"] = "Between";
	
	// the end of search options settings	

	
//Filters settings
	$fdata["filterTotals"] = 0;	
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;	
	
		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;
	
				
		
	
//end of Filters settings	

	
	$tdataDeductions_Archive_Report["date"] = $fdata;
//	branch
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 2;
	$fdata["strName"] = "branch";
	$fdata["GoodName"] = "branch";
	$fdata["ownerTable"] = "deductionsarchive";
	$fdata["Label"] = GetFieldLabel("Deductions_Archive_Report","branch"); 
	$fdata["FieldType"] = 200;
	
		// report field settings
					// end of report field settings
	
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		$fdata["bInlineAdd"] = true; 
	
		$fdata["bEditPage"] = true; 
	
		$fdata["bInlineEdit"] = true; 
	
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "branch"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "branch";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["report"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text field");
	
			
	
	


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
			$edata["HTML5InuptType"] = "text";
	
		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=50";
	
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
		
		
	
		
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
	// the end of search options settings	

	
//Filters settings
	$fdata["filterTotals"] = 0;	
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;	
	
		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;
	
				
		
	
//end of Filters settings	

	
	$tdataDeductions_Archive_Report["branch"] = $fdata;
//	employeeidnumber
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 3;
	$fdata["strName"] = "employeeidnumber";
	$fdata["GoodName"] = "employeeidnumber";
	$fdata["ownerTable"] = "deductionsarchive";
	$fdata["Label"] = GetFieldLabel("Deductions_Archive_Report","employeeidnumber"); 
	$fdata["FieldType"] = 3;
	
		// report field settings
					// end of report field settings
	
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		$fdata["bInlineAdd"] = true; 
	
		$fdata["bEditPage"] = true; 
	
		$fdata["bInlineEdit"] = true; 
	
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "employeeidnumber"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "employeeidnumber";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["report"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text field");
	
			
	
	


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
			$edata["HTML5InuptType"] = "number";
	
		$edata["EditParams"] = "";
			
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");	
								
		
	//	End validation
	
		
		
		
	
		
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
	// the end of search options settings	

	

	
	$tdataDeductions_Archive_Report["employeeidnumber"] = $fdata;
//	employeename
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 4;
	$fdata["strName"] = "employeename";
	$fdata["GoodName"] = "employeename";
	$fdata["ownerTable"] = "deductionsarchive";
	$fdata["Label"] = GetFieldLabel("Deductions_Archive_Report","employeename"); 
	$fdata["FieldType"] = 200;
	
		// report field settings
					// end of report field settings
	
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		$fdata["bInlineAdd"] = true; 
	
		$fdata["bEditPage"] = true; 
	
		$fdata["bInlineEdit"] = true; 
	
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "employeename"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "employeename";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["report"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text field");
	
			
	
	


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
			$edata["HTML5InuptType"] = "text";
	
		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=50";
	
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
		
		
	
		
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
	// the end of search options settings	

	

	
	$tdataDeductions_Archive_Report["employeename"] = $fdata;
//	deductionamount
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 5;
	$fdata["strName"] = "deductionamount";
	$fdata["GoodName"] = "deductionamount";
	$fdata["ownerTable"] = "deductionsarchive";
	$fdata["Label"] = GetFieldLabel("Deductions_Archive_Report","deductionamount"); 
	$fdata["FieldType"] = 14;
	
		// report field settings
					// end of report field settings
	
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		$fdata["bInlineAdd"] = true; 
	
		$fdata["bEditPage"] = true; 
	
		$fdata["bInlineEdit"] = true; 
	
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "deductionamount"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "deductionamount";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "Number");
	
		
		
		
		
		
		
		$vdata["DecimalDigits"] = 2;
	
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["report"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text field");
	
			
	
	


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
			$edata["HTML5InuptType"] = "number";
	
		$edata["EditParams"] = "";
			
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");	
								
		
	//	End validation
	
		
		
		
	
		
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
	// the end of search options settings	

	

	
	$tdataDeductions_Archive_Report["deductionamount"] = $fdata;
//	deductionreason
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 6;
	$fdata["strName"] = "deductionreason";
	$fdata["GoodName"] = "deductionreason";
	$fdata["ownerTable"] = "deductionsarchive";
	$fdata["Label"] = GetFieldLabel("Deductions_Archive_Report","deductionreason"); 
	$fdata["FieldType"] = 200;
	
		// report field settings
					// end of report field settings
	
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		$fdata["bInlineAdd"] = true; 
	
		$fdata["bEditPage"] = true; 
	
		$fdata["bInlineEdit"] = true; 
	
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "deductionreason"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "deductionreason";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["report"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text field");
	
			
	
	


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
			$edata["HTML5InuptType"] = "text";
	
		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=50";
	
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
		
		
	
		
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
	// the end of search options settings	

	

	
	$tdataDeductions_Archive_Report["deductionreason"] = $fdata;
//	duration
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 7;
	$fdata["strName"] = "duration";
	$fdata["GoodName"] = "duration";
	$fdata["ownerTable"] = "deductionsarchive";
	$fdata["Label"] = GetFieldLabel("Deductions_Archive_Report","duration"); 
	$fdata["FieldType"] = 200;
	
		// report field settings
					// end of report field settings
	
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		$fdata["bInlineAdd"] = true; 
	
		$fdata["bEditPage"] = true; 
	
		$fdata["bInlineEdit"] = true; 
	
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "duration"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "duration";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["report"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Lookup wizard");
	
			
	
	
// Begin Lookup settings
		$edata["LookupType"] = 0;
		$edata["autoCompleteFieldsOnEdit"] = 0;
	$edata["autoCompleteFields"] = array();
		$edata["LCType"] = 0;
		
		
		
		$edata["LookupValues"] = array();
	$edata["LookupValues"][] = "One Time";
	$edata["LookupValues"][] = "Start";
	$edata["LookupValues"][] = "Stop";

		
		$edata["SelectSize"] = 1;
		
// End Lookup Settings


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
		
		
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
		
		
	
		
	$fdata["EditFormats"]["search"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		$fdata["defaultSearchOption"] = "Equals";
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Empty");
// the end of search options settings	

	

	
	$tdataDeductions_Archive_Report["duration"] = $fdata;

	
$tables_data["Deductions Archive Report"]=&$tdataDeductions_Archive_Report;
$field_labels["Deductions_Archive_Report"] = &$fieldLabelsDeductions_Archive_Report;
$fieldToolTips["Deductions Archive Report"] = &$fieldToolTipsDeductions_Archive_Report;
$page_titles["Deductions_Archive_Report"] = &$pageTitlesDeductions_Archive_Report;

// -----------------start  prepare master-details data arrays ------------------------------//
// tables which are detail tables for current table (master)
$detailsTablesData["Deductions Archive Report"] = array();
	
// tables which are master tables for current table (detail)
$masterTablesData["Deductions Archive Report"] = array();


// -----------------end  prepare master-details data arrays ------------------------------//

require_once(getabspath("classes/sql.php"));










function createSqlQuery_Deductions_Archive_Report()
{
$proto0=array();
$proto0["m_strHead"] = "SELECT";
$proto0["m_strFieldList"] = "`date`,  branch,  employeeidnumber,  employeename,  deductionamount,  deductionreason,  duration";
$proto0["m_strFrom"] = "FROM deductionsarchive";
$proto0["m_strWhere"] = "";
$proto0["m_strOrderBy"] = "ORDER BY deductionreason, employeeidnumber";
$proto0["m_strTail"] = "";
			$proto0["cipherer"] = null;
$proto1=array();
$proto1["m_sql"] = "";
$proto1["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto1["m_column"]=$obj;
$proto1["m_contained"] = array();
$proto1["m_strCase"] = "";
$proto1["m_havingmode"] = false;
$proto1["m_inBrackets"] = false;
$proto1["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto1);

$proto0["m_where"] = $obj;
$proto3=array();
$proto3["m_sql"] = "";
$proto3["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto3["m_column"]=$obj;
$proto3["m_contained"] = array();
$proto3["m_strCase"] = "";
$proto3["m_havingmode"] = false;
$proto3["m_inBrackets"] = false;
$proto3["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto3);

$proto0["m_having"] = $obj;
$proto0["m_fieldlist"] = array();
						$proto5=array();
			$obj = new SQLField(array(
	"m_strName" => "date",
	"m_strTable" => "deductionsarchive",
	"m_srcTableName" => "Deductions Archive Report"
));

$proto5["m_sql"] = "`date`";
$proto5["m_srcTableName"] = "Deductions Archive Report";
$proto5["m_expr"]=$obj;
$proto5["m_alias"] = "";
$obj = new SQLFieldListItem($proto5);

$proto0["m_fieldlist"][]=$obj;
						$proto7=array();
			$obj = new SQLField(array(
	"m_strName" => "branch",
	"m_strTable" => "deductionsarchive",
	"m_srcTableName" => "Deductions Archive Report"
));

$proto7["m_sql"] = "branch";
$proto7["m_srcTableName"] = "Deductions Archive Report";
$proto7["m_expr"]=$obj;
$proto7["m_alias"] = "";
$obj = new SQLFieldListItem($proto7);

$proto0["m_fieldlist"][]=$obj;
						$proto9=array();
			$obj = new SQLField(array(
	"m_strName" => "employeeidnumber",
	"m_strTable" => "deductionsarchive",
	"m_srcTableName" => "Deductions Archive Report"
));

$proto9["m_sql"] = "employeeidnumber";
$proto9["m_srcTableName"] = "Deductions Archive Report";
$proto9["m_expr"]=$obj;
$proto9["m_alias"] = "";
$obj = new SQLFieldListItem($proto9);

$proto0["m_fieldlist"][]=$obj;
						$proto11=array();
			$obj = new SQLField(array(
	"m_strName" => "employeename",
	"m_strTable" => "deductionsarchive",
	"m_srcTableName" => "Deductions Archive Report"
));

$proto11["m_sql"] = "employeename";
$proto11["m_srcTableName"] = "Deductions Archive Report";
$proto11["m_expr"]=$obj;
$proto11["m_alias"] = "";
$obj = new SQLFieldListItem($proto11);

$proto0["m_fieldlist"][]=$obj;
						$proto13=array();
			$obj = new SQLField(array(
	"m_strName" => "deductionamount",
	"m_strTable" => "deductionsarchive",
	"m_srcTableName" => "Deductions Archive Report"
));

$proto13["m_sql"] = "deductionamount";
$proto13["m_srcTableName"] = "Deductions Archive Report";
$proto13["m_expr"]=$obj;
$proto13["m_alias"] = "";
$obj = new SQLFieldListItem($proto13);

$proto0["m_fieldlist"][]=$obj;
						$proto15=array();
			$obj = new SQLField(array(
	"m_strName" => "deductionreason",
	"m_strTable" => "deductionsarchive",
	"m_srcTableName" => "Deductions Archive Report"
));

$proto15["m_sql"] = "deductionreason";
$proto15["m_srcTableName"] = "Deductions Archive Report";
$proto15["m_expr"]=$obj;
$proto15["m_alias"] = "";
$obj = new SQLFieldListItem($proto15);

$proto0["m_fieldlist"][]=$obj;
						$proto17=array();
			$obj = new SQLField(array(
	"m_strName" => "duration",
	"m_strTable" => "deductionsarchive",
	"m_srcTableName" => "Deductions Archive Report"
));

$proto17["m_sql"] = "duration";
$proto17["m_srcTableName"] = "Deductions Archive Report";
$proto17["m_expr"]=$obj;
$proto17["m_alias"] = "";
$obj = new SQLFieldListItem($proto17);

$proto0["m_fieldlist"][]=$obj;
$proto0["m_fromlist"] = array();
												$proto19=array();
$proto19["m_link"] = "SQLL_MAIN";
			$proto20=array();
$proto20["m_strName"] = "deductionsarchive";
$proto20["m_srcTableName"] = "Deductions Archive Report";
$proto20["m_columns"] = array();
$proto20["m_columns"][] = "newID";
$proto20["m_columns"][] = "ID";
$proto20["m_columns"][] = "date";
$proto20["m_columns"][] = "branch";
$proto20["m_columns"][] = "employeeidnumber";
$proto20["m_columns"][] = "employeename";
$proto20["m_columns"][] = "deductionamount";
$proto20["m_columns"][] = "deductionreason";
$proto20["m_columns"][] = "duration";
$obj = new SQLTable($proto20);

$proto19["m_table"] = $obj;
$proto19["m_sql"] = "deductionsarchive";
$proto19["m_alias"] = "";
$proto19["m_srcTableName"] = "Deductions Archive Report";
$proto21=array();
$proto21["m_sql"] = "";
$proto21["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto21["m_column"]=$obj;
$proto21["m_contained"] = array();
$proto21["m_strCase"] = "";
$proto21["m_havingmode"] = false;
$proto21["m_inBrackets"] = false;
$proto21["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto21);

$proto19["m_joinon"] = $obj;
$obj = new SQLFromListItem($proto19);

$proto0["m_fromlist"][]=$obj;
$proto0["m_groupby"] = array();
$proto0["m_orderby"] = array();
												$proto23=array();
						$obj = new SQLField(array(
	"m_strName" => "deductionreason",
	"m_strTable" => "deductionsarchive",
	"m_srcTableName" => "Deductions Archive Report"
));

$proto23["m_column"]=$obj;
$proto23["m_bAsc"] = 1;
$proto23["m_nColumn"] = 0;
$obj = new SQLOrderByItem($proto23);

$proto0["m_orderby"][]=$obj;					
												$proto25=array();
						$obj = new SQLField(array(
	"m_strName" => "employeeidnumber",
	"m_strTable" => "deductionsarchive",
	"m_srcTableName" => "Deductions Archive Report"
));

$proto25["m_column"]=$obj;
$proto25["m_bAsc"] = 1;
$proto25["m_nColumn"] = 0;
$obj = new SQLOrderByItem($proto25);

$proto0["m_orderby"][]=$obj;					
$proto0["m_srcTableName"]="Deductions Archive Report";		
$obj = new SQLQuery($proto0);

	return $obj;
}
$queryData_Deductions_Archive_Report = createSqlQuery_Deductions_Archive_Report();


	
							
	
$tdataDeductions_Archive_Report[".sqlquery"] = $queryData_Deductions_Archive_Report;

$tableEvents["Deductions Archive Report"] = new eventsBase;
$tdataDeductions_Archive_Report[".hasEvents"] = false;

?>