<?php 
class eventclass_deductionsarchive  extends eventsBase
{ 
	function eventclass_deductionsarchive()
	{
	// fill list of events
		$this->events["BeforeEdit"]=true;


//	onscreen events

	}

//	handlers

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
				// Before record updated
function BeforeEdit(&$values, $where, &$oldvalues, &$keys, &$message, $inline, &$pageObject)
{

		
//**********  Insert a record into another table  ************

$sql = "INSERT INTO AnotherTable (name, email, age) values ('Bob Smith', 'bobsmith@gmail.com', 32)";
CustomQuery($sql);


;		
} // function BeforeEdit

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
								
		
		
			
		
		
		
		
//	onscreen events

} 
?>
