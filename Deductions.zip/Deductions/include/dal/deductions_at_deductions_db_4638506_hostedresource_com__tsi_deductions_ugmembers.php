<?php
$dalTabletsi_deductions_ugmembers = array();
$dalTabletsi_deductions_ugmembers["UserName"] = array("type"=>200,"varname"=>"UserName");
$dalTabletsi_deductions_ugmembers["GroupID"] = array("type"=>3,"varname"=>"GroupID");
	$dalTabletsi_deductions_ugmembers["UserName"]["key"]=true;
	$dalTabletsi_deductions_ugmembers["GroupID"]["key"]=true;

$dal_info["deductions_at_deductions_db_4638506_hostedresource_com__tsi_deductions_ugmembers"] = &$dalTabletsi_deductions_ugmembers;
?>