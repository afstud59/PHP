<?php
$dalTabledeductions = array();
$dalTabledeductions["ID"] = array("type"=>3,"varname"=>"ID");
$dalTabledeductions["date"] = array("type"=>7,"varname"=>"date");
$dalTabledeductions["branch"] = array("type"=>200,"varname"=>"branch");
$dalTabledeductions["employeeidnumber"] = array("type"=>3,"varname"=>"employeeidnumber");
$dalTabledeductions["employeename"] = array("type"=>200,"varname"=>"employeename");
$dalTabledeductions["deductionamount"] = array("type"=>14,"varname"=>"deductionamount");
$dalTabledeductions["deductionreason"] = array("type"=>200,"varname"=>"deductionreason");
$dalTabledeductions["duration"] = array("type"=>200,"varname"=>"duration");
	$dalTabledeductions["ID"]["key"]=true;

$dal_info["deductions_at_deductions_db_4638506_hostedresource_com__deductions"] = &$dalTabledeductions;
?>