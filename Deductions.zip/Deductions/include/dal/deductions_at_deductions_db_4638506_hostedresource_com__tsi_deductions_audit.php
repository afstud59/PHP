<?php
$dalTabletsi_deductions_audit = array();
$dalTabletsi_deductions_audit["id"] = array("type"=>3,"varname"=>"id");
$dalTabletsi_deductions_audit["datetime"] = array("type"=>135,"varname"=>"datetime");
$dalTabletsi_deductions_audit["ip"] = array("type"=>200,"varname"=>"ip");
$dalTabletsi_deductions_audit["user"] = array("type"=>200,"varname"=>"user");
$dalTabletsi_deductions_audit["table"] = array("type"=>200,"varname"=>"table");
$dalTabletsi_deductions_audit["action"] = array("type"=>200,"varname"=>"action");
$dalTabletsi_deductions_audit["description"] = array("type"=>201,"varname"=>"description");
	$dalTabletsi_deductions_audit["id"]["key"]=true;

$dal_info["deductions_at_deductions_db_4638506_hostedresource_com__tsi_deductions_audit"] = &$dalTabletsi_deductions_audit;
?>