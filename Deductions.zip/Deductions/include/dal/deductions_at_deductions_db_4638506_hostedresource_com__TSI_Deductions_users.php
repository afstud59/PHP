<?php
$dalTableTSI_Deductions_users = array();
$dalTableTSI_Deductions_users["ID"] = array("type"=>3,"varname"=>"ID");
$dalTableTSI_Deductions_users["username"] = array("type"=>200,"varname"=>"username");
$dalTableTSI_Deductions_users["password"] = array("type"=>200,"varname"=>"password");
$dalTableTSI_Deductions_users["email"] = array("type"=>200,"varname"=>"email");
$dalTableTSI_Deductions_users["fullname"] = array("type"=>200,"varname"=>"fullname");
$dalTableTSI_Deductions_users["groupid"] = array("type"=>200,"varname"=>"groupid");
$dalTableTSI_Deductions_users["active"] = array("type"=>3,"varname"=>"active");
	$dalTableTSI_Deductions_users["ID"]["key"]=true;

$dal_info["deductions_at_deductions_db_4638506_hostedresource_com__TSI_Deductions_users"] = &$dalTableTSI_Deductions_users;
?>