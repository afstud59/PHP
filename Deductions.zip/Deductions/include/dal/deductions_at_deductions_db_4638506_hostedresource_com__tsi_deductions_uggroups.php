<?php
$dalTabletsi_deductions_uggroups = array();
$dalTabletsi_deductions_uggroups["GroupID"] = array("type"=>3,"varname"=>"GroupID");
$dalTabletsi_deductions_uggroups["Label"] = array("type"=>200,"varname"=>"Label");
	$dalTabletsi_deductions_uggroups["GroupID"]["key"]=true;

$dal_info["deductions_at_deductions_db_4638506_hostedresource_com__tsi_deductions_uggroups"] = &$dalTabletsi_deductions_uggroups;
?>