<?php
$dalTabletsi_deductions_ugrights = array();
$dalTabletsi_deductions_ugrights["TableName"] = array("type"=>200,"varname"=>"TableName");
$dalTabletsi_deductions_ugrights["GroupID"] = array("type"=>3,"varname"=>"GroupID");
$dalTabletsi_deductions_ugrights["AccessMask"] = array("type"=>200,"varname"=>"AccessMask");
	$dalTabletsi_deductions_ugrights["TableName"]["key"]=true;
	$dalTabletsi_deductions_ugrights["GroupID"]["key"]=true;

$dal_info["deductions_at_deductions_db_4638506_hostedresource_com__tsi_deductions_ugrights"] = &$dalTabletsi_deductions_ugrights;
?>