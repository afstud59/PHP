<?php
$strTableName="deductionsarchive";
$_SESSION["OwnerID"] = $_SESSION["_".$strTableName."_OwnerID"];

$strOriginalTableName="deductionsarchive";

$gstrOrderBy="ORDER BY `date` DESC, employeeidnumber, deductionreason";
if(strlen($gstrOrderBy) && strtolower(substr($gstrOrderBy,0,8))!="order by")
	$gstrOrderBy="order by ".$gstrOrderBy;

// alias for 'SQLQuery' object
$gSettings = new ProjectSettings("deductionsarchive");
$gQuery = $gSettings->getSQLQuery();
$eventObj = &$tableEvents["deductionsarchive"];

$reportCaseSensitiveGroupFields = false;

$gstrSQL = $gQuery->gSQLWhere("");

?>