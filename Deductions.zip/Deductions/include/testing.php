<?php
$testingLinks=array();
$testingLinks["addlink_attrs"]="add_new";
$testingLinks["inlineaddlink_attrs"]="inline_add";
$testingLinks["editselectedlink_attrs"]="edit_selected";
$testingLinks["deletelink_attrs"]="delete_selected";
$testingLinks["exportselectedlink_attrs"]="export_selected";
$testingLinks["printselectedlink_attrs"]="print_selected";
$testingLinks["searchbutton_attrs"]="search";
$testingLinks["showallbutton_attrs"]="show_all";
$testingLinks["savealllink_attrs"]="save_all";
$testingLinks["cancelalllink_attrs"]="cancel_all";
$testingLinks["editlink_attrs"]="edit";
$testingLinks["inlineeditlink_attrs"]="inline_edit";
$testingLinks["viewlink_attrs"]="view";
$testingLinks["printlink_attrs"]="print";
$testingLinks["printpictlink_attrs"]="print_pict";
$testingLinks["printalllink_attrs"]="print_all";
$testingLinks["printallpictlink_attrs"]="print_all_pict";
$testingLinks["advsearchlink_attrs"]="adv_search";
$testingLinks["exportlink_attrs"]="export";
$testingLinks["importlink_attrs"]="import";
$testingLinks["logoutlink_attrs"]="logout";
$testingLinks["loginlink_attrs"]="login";
$testingLinks["guestlink_attrs"]="guest";
$testingLinks["registerlink_attrs"]="register";
$testingLinks["forgotpasswordlink_attrs"]="forgot_password";
$testingLinks["changepwdlink_attrs"]="change_password";
$testingLinks["savebutton_attrs"]="save";
$testingLinks["resetbutton_attrs"]="reset";
$testingLinks["cancelbutton_attrs"]="cancel";
$testingLinks["backbutton_attrs"]="back_to_list";
$testingLinks["prevbutton_attrs"]="prev";
$testingLinks["nextbutton_attrs"]="next";
$testingLinks["all_checkbox"]="all_seacrh";
$testingLinks["any_checkbox"]="any_search";
$testingLinks["allpageradio_attrs"]="all_page";
$testingLinks["pageradio_attrs"]="page";
$testingLinks["excelradio_attrs"]="excel";
$testingLinks["wordradio_attrs"]="word";
$testingLinks["csvradio_attrs"]="csv";
$testingLinks["xmlradio_attrs"]="xml";
$testingLinks["pdfradio_attrs"]="pdf";
$testingLinks["backtomasterlink_attrs"]="back_to_master";
$testingLinks["adminarealink_attrs"]="admin_area";
$testingLinks["exitaalink_attrs"]="exit_admin_area";
$testingLinks["selectalllink_attrs"]="select_all";
$testingLinks["backtolist_attrs"]="back_list";
$testingLinks["backlink_attrs"]="back";
$testingLinks["submit_attrs"]="submit";
$testingLinks["usernameradio_attrs"]="username";
$testingLinks["emailradio_attrs"]="email";
$testingLinks["pdflink_attrs"]="pdf_view";
$testingLinks["excellink_attrs"]="excel_view";
$testingLinks["wordlink_attrs"]="word_view";
$testingLinks["importfile_attrs"]="import_file";
$testingLinks["checkbox_attrs"]="check_record";
$testingLinks["rememberbox_attrs"]="remember_box";
$testingLinks["userheaderlink_attrs"]="user_header";
$testingLinks["groupheaderlink_attrs"]="group_header";
$testingLinks["groupheaderbox_attrs"]="group_header_box";
$testingLinks["usercheckbox_attrs"]="user_check_box";
$testingLinks["groupbox_attrs"]="group_box";
$testingLinks["addgroup_attrs"]="add_group";
$testingLinks["delgroup_attrs"]="del_group";
$testingLinks["rengroup_attrs"]="rengroup_attrs";
$testingLinks["savegroup_attrs"]="save_group";
$testingLinks["cancelgroup_attrs"]="cancel_group";
$testingLinks["add_headcheckbox"]="add_head_checkbox";
$testingLinks["edt_headcheckbox"]="edt_head_checkbox";
$testingLinks["del_headcheckbox"]="del_head_checkbox";
$testingLinks["lst_headcheckbox"]="lst_head_checkbox";
$testingLinks["exp_headcheckbox"]="exp_head_checkbox";
$testingLinks["imp_headcheckbox"]="imp_head_checkbox";
$testingLinks["adm_headcheckbox"]="adm_head_checkbox";
$testingLinks["tablecheckbox_attrs"]="table_checkbox";
$testingLinks["add_checkbox"]="add_checkbox";
$testingLinks["edt_checkbox"]="edt_checkbox";
$testingLinks["del_checkbox"]="del_checkbox";
$testingLinks["lst_checkbox"]="lst_checkbox";
$testingLinks["exp_checkbox"]="exp_checkbox";
$testingLinks["imp_checkbox"]="imp_checkbox";
$testingLinks["adm_checkbox"]="adm_checkbox";
$testingLinks["cancelonclick"]="cancel_onclick";
$testingLinks["groupname_attrs"]="group_name";
$testingLinks["quickjump_attrs"]="quick_jump";
?>
