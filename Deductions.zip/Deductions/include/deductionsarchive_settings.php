<?php
require_once(getabspath("classes/cipherer.php"));




$tdatadeductionsarchive = array();	
	$tdatadeductionsarchive[".truncateText"] = true;
	$tdatadeductionsarchive[".NumberOfChars"] = 80; 
	$tdatadeductionsarchive[".ShortName"] = "deductionsarchive";
	$tdatadeductionsarchive[".OwnerID"] = "";
	$tdatadeductionsarchive[".OriginalTable"] = "deductionsarchive";

//	field labels
$fieldLabelsdeductionsarchive = array();
$fieldToolTipsdeductionsarchive = array();
$pageTitlesdeductionsarchive = array();

if(mlang_getcurrentlang()=="English")
{
	$fieldLabelsdeductionsarchive["English"] = array();
	$fieldToolTipsdeductionsarchive["English"] = array();
	$pageTitlesdeductionsarchive["English"] = array();
	$fieldLabelsdeductionsarchive["English"]["date"] = "Date";
	$fieldToolTipsdeductionsarchive["English"]["date"] = "";
	$fieldLabelsdeductionsarchive["English"]["branch"] = "Branch";
	$fieldToolTipsdeductionsarchive["English"]["branch"] = "";
	$fieldLabelsdeductionsarchive["English"]["employeeidnumber"] = "Employee ID Number";
	$fieldToolTipsdeductionsarchive["English"]["employeeidnumber"] = "";
	$fieldLabelsdeductionsarchive["English"]["employeename"] = "Employee Name";
	$fieldToolTipsdeductionsarchive["English"]["employeename"] = "";
	$fieldLabelsdeductionsarchive["English"]["deductionamount"] = "Deduction Amount";
	$fieldToolTipsdeductionsarchive["English"]["deductionamount"] = "";
	$fieldLabelsdeductionsarchive["English"]["deductionreason"] = "Deduction Reason";
	$fieldToolTipsdeductionsarchive["English"]["deductionreason"] = "";
	$fieldLabelsdeductionsarchive["English"]["ID"] = "ID";
	$fieldToolTipsdeductionsarchive["English"]["ID"] = "";
	$fieldLabelsdeductionsarchive["English"]["newID"] = "New ID";
	$fieldToolTipsdeductionsarchive["English"]["newID"] = "";
	$fieldLabelsdeductionsarchive["English"]["duration"] = "Duration";
	$fieldToolTipsdeductionsarchive["English"]["duration"] = "";
	if (count($fieldToolTipsdeductionsarchive["English"]))
		$tdatadeductionsarchive[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="")
{
	$fieldLabelsdeductionsarchive[""] = array();
	$fieldToolTipsdeductionsarchive[""] = array();
	$pageTitlesdeductionsarchive[""] = array();
	if (count($fieldToolTipsdeductionsarchive[""]))
		$tdatadeductionsarchive[".isUseToolTips"] = true;
}
	
	
	$tdatadeductionsarchive[".NCSearch"] = true;



$tdatadeductionsarchive[".shortTableName"] = "deductionsarchive";
$tdatadeductionsarchive[".nSecOptions"] = 0;
$tdatadeductionsarchive[".recsPerRowList"] = 1;
$tdatadeductionsarchive[".recsPerRowPrint"] = 1;
$tdatadeductionsarchive[".mainTableOwnerID"] = "";
$tdatadeductionsarchive[".moveNext"] = 1;
$tdatadeductionsarchive[".entityType"] = 0;

$tdatadeductionsarchive[".strOriginalTableName"] = "deductionsarchive";




$tdatadeductionsarchive[".showAddInPopup"] = false;

$tdatadeductionsarchive[".showEditInPopup"] = false;

$tdatadeductionsarchive[".showViewInPopup"] = false;

//page's base css files names
$popupPagesLayoutNames = array();
$tdatadeductionsarchive[".popupPagesLayoutNames"] = $popupPagesLayoutNames;


$tdatadeductionsarchive[".fieldsForRegister"] = array();

$tdatadeductionsarchive[".listAjax"] = false;

	$tdatadeductionsarchive[".audit"] = false;

	$tdatadeductionsarchive[".locking"] = false;

$tdatadeductionsarchive[".edit"] = true;
$tdatadeductionsarchive[".afterEditAction"] = 1;
$tdatadeductionsarchive[".closePopupAfterEdit"] = 1;
$tdatadeductionsarchive[".afterEditActionDetTable"] = "";

$tdatadeductionsarchive[".add"] = true;
$tdatadeductionsarchive[".afterAddAction"] = 1;
$tdatadeductionsarchive[".closePopupAfterAdd"] = 1;
$tdatadeductionsarchive[".afterAddActionDetTable"] = "";

$tdatadeductionsarchive[".list"] = true;

$tdatadeductionsarchive[".inlineEdit"] = true;
$tdatadeductionsarchive[".inlineAdd"] = true;
$tdatadeductionsarchive[".view"] = true;


$tdatadeductionsarchive[".exportTo"] = true;

$tdatadeductionsarchive[".printFriendly"] = true;

$tdatadeductionsarchive[".delete"] = true;

$tdatadeductionsarchive[".showSimpleSearchOptions"] = false;

// search Saving settings
$tdatadeductionsarchive[".searchSaving"] = false;
//

$tdatadeductionsarchive[".showSearchPanel"] = true;
		$tdatadeductionsarchive[".flexibleSearch"] = true;		

if (isMobile())
	$tdatadeductionsarchive[".isUseAjaxSuggest"] = false;
else 
	$tdatadeductionsarchive[".isUseAjaxSuggest"] = true;

$tdatadeductionsarchive[".rowHighlite"] = true;



$tdatadeductionsarchive[".addPageEvents"] = false;

// use timepicker for search panel
$tdatadeductionsarchive[".isUseTimeForSearch"] = false;





$tdatadeductionsarchive[".allSearchFields"] = array();
$tdatadeductionsarchive[".filterFields"] = array();
$tdatadeductionsarchive[".requiredSearchFields"] = array();

$tdatadeductionsarchive[".allSearchFields"][] = "newID";
	$tdatadeductionsarchive[".allSearchFields"][] = "ID";
	$tdatadeductionsarchive[".allSearchFields"][] = "date";
	$tdatadeductionsarchive[".allSearchFields"][] = "branch";
	$tdatadeductionsarchive[".allSearchFields"][] = "employeeidnumber";
	$tdatadeductionsarchive[".allSearchFields"][] = "employeename";
	$tdatadeductionsarchive[".allSearchFields"][] = "deductionamount";
	$tdatadeductionsarchive[".allSearchFields"][] = "deductionreason";
	$tdatadeductionsarchive[".allSearchFields"][] = "duration";
	

$tdatadeductionsarchive[".googleLikeFields"] = array();
$tdatadeductionsarchive[".googleLikeFields"][] = "ID";
$tdatadeductionsarchive[".googleLikeFields"][] = "date";
$tdatadeductionsarchive[".googleLikeFields"][] = "branch";
$tdatadeductionsarchive[".googleLikeFields"][] = "employeeidnumber";
$tdatadeductionsarchive[".googleLikeFields"][] = "employeename";
$tdatadeductionsarchive[".googleLikeFields"][] = "deductionamount";
$tdatadeductionsarchive[".googleLikeFields"][] = "deductionreason";
$tdatadeductionsarchive[".googleLikeFields"][] = "newID";
$tdatadeductionsarchive[".googleLikeFields"][] = "duration";


$tdatadeductionsarchive[".advSearchFields"] = array();
$tdatadeductionsarchive[".advSearchFields"][] = "newID";
$tdatadeductionsarchive[".advSearchFields"][] = "ID";
$tdatadeductionsarchive[".advSearchFields"][] = "date";
$tdatadeductionsarchive[".advSearchFields"][] = "branch";
$tdatadeductionsarchive[".advSearchFields"][] = "employeeidnumber";
$tdatadeductionsarchive[".advSearchFields"][] = "employeename";
$tdatadeductionsarchive[".advSearchFields"][] = "deductionamount";
$tdatadeductionsarchive[".advSearchFields"][] = "deductionreason";
$tdatadeductionsarchive[".advSearchFields"][] = "duration";

$tdatadeductionsarchive[".tableType"] = "list";

$tdatadeductionsarchive[".printerPageOrientation"] = 0;
$tdatadeductionsarchive[".nPrinterPageScale"] = 100;

$tdatadeductionsarchive[".nPrinterSplitRecords"] = 40;

$tdatadeductionsarchive[".nPrinterPDFSplitRecords"] = 40;



$tdatadeductionsarchive[".geocodingEnabled"] = false;




	





// view page pdf

// print page pdf


$tdatadeductionsarchive[".pageSize"] = 50;

$tdatadeductionsarchive[".warnLeavingPages"] = true;



$tstrOrderBy = "ORDER BY `date` DESC, employeeidnumber, deductionreason";
if(strlen($tstrOrderBy) && strtolower(substr($tstrOrderBy,0,8))!="order by")
	$tstrOrderBy = "order by ".$tstrOrderBy;
$tdatadeductionsarchive[".strOrderBy"] = $tstrOrderBy;

$tdatadeductionsarchive[".orderindexes"] = array();
$tdatadeductionsarchive[".orderindexes"][] = array(2, (0 ? "ASC" : "DESC"), "`date`");
$tdatadeductionsarchive[".orderindexes"][] = array(4, (1 ? "ASC" : "DESC"), "employeeidnumber");
$tdatadeductionsarchive[".orderindexes"][] = array(7, (1 ? "ASC" : "DESC"), "deductionreason");

$tdatadeductionsarchive[".sqlHead"] = "SELECT ID,  `date`,  branch,  employeeidnumber,  employeename,  deductionamount,  deductionreason,  newID,  duration";
$tdatadeductionsarchive[".sqlFrom"] = "FROM deductionsarchive";
$tdatadeductionsarchive[".sqlWhereExpr"] = "";
$tdatadeductionsarchive[".sqlTail"] = "";









//fill array of records per page for list and report without group fields
$arrRPP = array();
$arrRPP[] = 10;
$arrRPP[] = 20;
$arrRPP[] = 30;
$arrRPP[] = 50;
$arrRPP[] = 100;
$arrRPP[] = 500;
$arrRPP[] = -1;
$tdatadeductionsarchive[".arrRecsPerPage"] = $arrRPP;

//fill array of groups per page for report with group fields
$arrGPP = array();
$arrGPP[] = 1;
$arrGPP[] = 3;
$arrGPP[] = 5;
$arrGPP[] = 10;
$arrGPP[] = 50;
$arrGPP[] = 100;
$arrGPP[] = -1;
$tdatadeductionsarchive[".arrGroupsPerPage"] = $arrGPP;

$tdatadeductionsarchive[".highlightSearchResults"] = true;

$tableKeysdeductionsarchive = array();
$tableKeysdeductionsarchive[] = "newID";
$tdatadeductionsarchive[".Keys"] = $tableKeysdeductionsarchive;

$tdatadeductionsarchive[".listFields"] = array();
$tdatadeductionsarchive[".listFields"][] = "newID";
$tdatadeductionsarchive[".listFields"][] = "ID";
$tdatadeductionsarchive[".listFields"][] = "date";
$tdatadeductionsarchive[".listFields"][] = "branch";
$tdatadeductionsarchive[".listFields"][] = "employeeidnumber";
$tdatadeductionsarchive[".listFields"][] = "employeename";
$tdatadeductionsarchive[".listFields"][] = "deductionamount";
$tdatadeductionsarchive[".listFields"][] = "deductionreason";
$tdatadeductionsarchive[".listFields"][] = "duration";

$tdatadeductionsarchive[".hideMobileList"] = array();


$tdatadeductionsarchive[".viewFields"] = array();
$tdatadeductionsarchive[".viewFields"][] = "newID";
$tdatadeductionsarchive[".viewFields"][] = "ID";
$tdatadeductionsarchive[".viewFields"][] = "date";
$tdatadeductionsarchive[".viewFields"][] = "branch";
$tdatadeductionsarchive[".viewFields"][] = "employeeidnumber";
$tdatadeductionsarchive[".viewFields"][] = "employeename";
$tdatadeductionsarchive[".viewFields"][] = "deductionamount";
$tdatadeductionsarchive[".viewFields"][] = "deductionreason";
$tdatadeductionsarchive[".viewFields"][] = "duration";

$tdatadeductionsarchive[".addFields"] = array();
$tdatadeductionsarchive[".addFields"][] = "date";
$tdatadeductionsarchive[".addFields"][] = "branch";
$tdatadeductionsarchive[".addFields"][] = "employeeidnumber";
$tdatadeductionsarchive[".addFields"][] = "employeename";
$tdatadeductionsarchive[".addFields"][] = "deductionamount";
$tdatadeductionsarchive[".addFields"][] = "deductionreason";
$tdatadeductionsarchive[".addFields"][] = "duration";

$tdatadeductionsarchive[".masterListFields"] = array();
$tdatadeductionsarchive[".masterListFields"][] = "ID";
$tdatadeductionsarchive[".masterListFields"][] = "date";
$tdatadeductionsarchive[".masterListFields"][] = "branch";
$tdatadeductionsarchive[".masterListFields"][] = "employeeidnumber";
$tdatadeductionsarchive[".masterListFields"][] = "employeename";
$tdatadeductionsarchive[".masterListFields"][] = "deductionamount";
$tdatadeductionsarchive[".masterListFields"][] = "deductionreason";
$tdatadeductionsarchive[".masterListFields"][] = "newID";
$tdatadeductionsarchive[".masterListFields"][] = "duration";

$tdatadeductionsarchive[".inlineAddFields"] = array();
$tdatadeductionsarchive[".inlineAddFields"][] = "date";
$tdatadeductionsarchive[".inlineAddFields"][] = "branch";
$tdatadeductionsarchive[".inlineAddFields"][] = "employeeidnumber";
$tdatadeductionsarchive[".inlineAddFields"][] = "employeename";
$tdatadeductionsarchive[".inlineAddFields"][] = "deductionamount";
$tdatadeductionsarchive[".inlineAddFields"][] = "deductionreason";
$tdatadeductionsarchive[".inlineAddFields"][] = "duration";

$tdatadeductionsarchive[".editFields"] = array();
$tdatadeductionsarchive[".editFields"][] = "date";
$tdatadeductionsarchive[".editFields"][] = "branch";
$tdatadeductionsarchive[".editFields"][] = "employeeidnumber";
$tdatadeductionsarchive[".editFields"][] = "employeename";
$tdatadeductionsarchive[".editFields"][] = "deductionamount";
$tdatadeductionsarchive[".editFields"][] = "deductionreason";
$tdatadeductionsarchive[".editFields"][] = "duration";

$tdatadeductionsarchive[".inlineEditFields"] = array();
$tdatadeductionsarchive[".inlineEditFields"][] = "date";
$tdatadeductionsarchive[".inlineEditFields"][] = "branch";
$tdatadeductionsarchive[".inlineEditFields"][] = "employeeidnumber";
$tdatadeductionsarchive[".inlineEditFields"][] = "employeename";
$tdatadeductionsarchive[".inlineEditFields"][] = "deductionamount";
$tdatadeductionsarchive[".inlineEditFields"][] = "deductionreason";
$tdatadeductionsarchive[".inlineEditFields"][] = "duration";

$tdatadeductionsarchive[".exportFields"] = array();
$tdatadeductionsarchive[".exportFields"][] = "newID";
$tdatadeductionsarchive[".exportFields"][] = "ID";
$tdatadeductionsarchive[".exportFields"][] = "date";
$tdatadeductionsarchive[".exportFields"][] = "branch";
$tdatadeductionsarchive[".exportFields"][] = "employeeidnumber";
$tdatadeductionsarchive[".exportFields"][] = "employeename";
$tdatadeductionsarchive[".exportFields"][] = "deductionamount";
$tdatadeductionsarchive[".exportFields"][] = "deductionreason";
$tdatadeductionsarchive[".exportFields"][] = "duration";

$tdatadeductionsarchive[".importFields"] = array();

$tdatadeductionsarchive[".printFields"] = array();
$tdatadeductionsarchive[".printFields"][] = "newID";
$tdatadeductionsarchive[".printFields"][] = "ID";
$tdatadeductionsarchive[".printFields"][] = "date";
$tdatadeductionsarchive[".printFields"][] = "branch";
$tdatadeductionsarchive[".printFields"][] = "employeeidnumber";
$tdatadeductionsarchive[".printFields"][] = "employeename";
$tdatadeductionsarchive[".printFields"][] = "deductionamount";
$tdatadeductionsarchive[".printFields"][] = "deductionreason";
$tdatadeductionsarchive[".printFields"][] = "duration";

//	ID
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 1;
	$fdata["strName"] = "ID";
	$fdata["GoodName"] = "ID";
	$fdata["ownerTable"] = "deductionsarchive";
	$fdata["Label"] = GetFieldLabel("deductionsarchive","ID"); 
	$fdata["FieldType"] = 3;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		
		
		
		
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "ID"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "ID";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text field");
	
			
	
	


		$edata["IsRequired"] = true; 
	
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
			$edata["HTML5InuptType"] = "number";
	
		$edata["EditParams"] = "";
			
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");	
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
			
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the user's search options list 
		$fdata["searchOptionsList"] = array();
		$fdata["searchOptionsList"][] = "Contains";
		$fdata["searchOptionsList"][] = "Equals";
		$fdata["searchOptionsList"][] = "Starts with";
		$fdata["searchOptionsList"][] = "More than";
		$fdata["searchOptionsList"][] = "Less than";
		$fdata["searchOptionsList"][] = "Between";
		$fdata["searchOptionsList"][] = "Empty";
		$fdata["searchOptionsList"][] = "NOT Contains";
		$fdata["searchOptionsList"][] = "NOT Equals";
		$fdata["searchOptionsList"][] = "NOT Starts with";
		$fdata["searchOptionsList"][] = "NOT More than";
		$fdata["searchOptionsList"][] = "NOT Less than";
		$fdata["searchOptionsList"][] = "NOT Between";
		$fdata["searchOptionsList"][] = "NOT Empty";
// the end of search options settings	

	

	
	$tdatadeductionsarchive["ID"] = $fdata;
//	date
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 2;
	$fdata["strName"] = "date";
	$fdata["GoodName"] = "date";
	$fdata["ownerTable"] = "deductionsarchive";
	$fdata["Label"] = GetFieldLabel("deductionsarchive","date"); 
	$fdata["FieldType"] = 7;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		$fdata["bInlineAdd"] = true; 
	
		$fdata["bEditPage"] = true; 
	
		$fdata["bInlineEdit"] = true; 
	
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "date"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "`date`";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "Short Date");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Date");
	
			
	
	


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		$edata["DateEditType"] = 11; 
	$edata["InitialYearFactor"] = 100; 
	$edata["LastYearFactor"] = 10; 
	
		
		
		
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the user's search options list 
		$fdata["searchOptionsList"] = array();
		$fdata["searchOptionsList"][] = "Equals";
		$fdata["searchOptionsList"][] = "More than";
		$fdata["searchOptionsList"][] = "Less than";
		$fdata["searchOptionsList"][] = "Between";
		$fdata["searchOptionsList"][] = "Empty";
		$fdata["searchOptionsList"][] = "NOT Equals";
		$fdata["searchOptionsList"][] = "NOT More than";
		$fdata["searchOptionsList"][] = "NOT Less than";
		$fdata["searchOptionsList"][] = "NOT Between";
		$fdata["searchOptionsList"][] = "NOT Empty";
// the end of search options settings	

	

	
	$tdatadeductionsarchive["date"] = $fdata;
//	branch
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 3;
	$fdata["strName"] = "branch";
	$fdata["GoodName"] = "branch";
	$fdata["ownerTable"] = "deductionsarchive";
	$fdata["Label"] = GetFieldLabel("deductionsarchive","branch"); 
	$fdata["FieldType"] = 200;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		$fdata["bInlineAdd"] = true; 
	
		$fdata["bEditPage"] = true; 
	
		$fdata["bInlineEdit"] = true; 
	
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "branch"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "branch";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text field");
	
			
	
	


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
			$edata["HTML5InuptType"] = "text";
	
		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=50";
	
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the user's search options list 
		$fdata["searchOptionsList"] = array();
		$fdata["searchOptionsList"][] = "Contains";
		$fdata["searchOptionsList"][] = "Equals";
		$fdata["searchOptionsList"][] = "Starts with";
		$fdata["searchOptionsList"][] = "More than";
		$fdata["searchOptionsList"][] = "Less than";
		$fdata["searchOptionsList"][] = "Between";
		$fdata["searchOptionsList"][] = "Empty";
		$fdata["searchOptionsList"][] = "NOT Contains";
		$fdata["searchOptionsList"][] = "NOT Equals";
		$fdata["searchOptionsList"][] = "NOT Starts with";
		$fdata["searchOptionsList"][] = "NOT More than";
		$fdata["searchOptionsList"][] = "NOT Less than";
		$fdata["searchOptionsList"][] = "NOT Between";
		$fdata["searchOptionsList"][] = "NOT Empty";
// the end of search options settings	

	

	
	$tdatadeductionsarchive["branch"] = $fdata;
//	employeeidnumber
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 4;
	$fdata["strName"] = "employeeidnumber";
	$fdata["GoodName"] = "employeeidnumber";
	$fdata["ownerTable"] = "deductionsarchive";
	$fdata["Label"] = GetFieldLabel("deductionsarchive","employeeidnumber"); 
	$fdata["FieldType"] = 3;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		$fdata["bInlineAdd"] = true; 
	
		$fdata["bEditPage"] = true; 
	
		$fdata["bInlineEdit"] = true; 
	
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "employeeidnumber"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "employeeidnumber";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text field");
	
			
	
	


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
			$edata["HTML5InuptType"] = "number";
	
		$edata["EditParams"] = "";
			
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");	
								
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the user's search options list 
		$fdata["searchOptionsList"] = array();
		$fdata["searchOptionsList"][] = "Contains";
		$fdata["searchOptionsList"][] = "Equals";
		$fdata["searchOptionsList"][] = "Starts with";
		$fdata["searchOptionsList"][] = "More than";
		$fdata["searchOptionsList"][] = "Less than";
		$fdata["searchOptionsList"][] = "Between";
		$fdata["searchOptionsList"][] = "Empty";
		$fdata["searchOptionsList"][] = "NOT Contains";
		$fdata["searchOptionsList"][] = "NOT Equals";
		$fdata["searchOptionsList"][] = "NOT Starts with";
		$fdata["searchOptionsList"][] = "NOT More than";
		$fdata["searchOptionsList"][] = "NOT Less than";
		$fdata["searchOptionsList"][] = "NOT Between";
		$fdata["searchOptionsList"][] = "NOT Empty";
// the end of search options settings	

	

	
	$tdatadeductionsarchive["employeeidnumber"] = $fdata;
//	employeename
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 5;
	$fdata["strName"] = "employeename";
	$fdata["GoodName"] = "employeename";
	$fdata["ownerTable"] = "deductionsarchive";
	$fdata["Label"] = GetFieldLabel("deductionsarchive","employeename"); 
	$fdata["FieldType"] = 200;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		$fdata["bInlineAdd"] = true; 
	
		$fdata["bEditPage"] = true; 
	
		$fdata["bInlineEdit"] = true; 
	
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "employeename"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "employeename";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text field");
	
			
	
	


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
			$edata["HTML5InuptType"] = "text";
	
		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=50";
	
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the user's search options list 
		$fdata["searchOptionsList"] = array();
		$fdata["searchOptionsList"][] = "Contains";
		$fdata["searchOptionsList"][] = "Equals";
		$fdata["searchOptionsList"][] = "Starts with";
		$fdata["searchOptionsList"][] = "More than";
		$fdata["searchOptionsList"][] = "Less than";
		$fdata["searchOptionsList"][] = "Between";
		$fdata["searchOptionsList"][] = "Empty";
		$fdata["searchOptionsList"][] = "NOT Contains";
		$fdata["searchOptionsList"][] = "NOT Equals";
		$fdata["searchOptionsList"][] = "NOT Starts with";
		$fdata["searchOptionsList"][] = "NOT More than";
		$fdata["searchOptionsList"][] = "NOT Less than";
		$fdata["searchOptionsList"][] = "NOT Between";
		$fdata["searchOptionsList"][] = "NOT Empty";
// the end of search options settings	

	

	
	$tdatadeductionsarchive["employeename"] = $fdata;
//	deductionamount
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 6;
	$fdata["strName"] = "deductionamount";
	$fdata["GoodName"] = "deductionamount";
	$fdata["ownerTable"] = "deductionsarchive";
	$fdata["Label"] = GetFieldLabel("deductionsarchive","deductionamount"); 
	$fdata["FieldType"] = 14;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		$fdata["bInlineAdd"] = true; 
	
		$fdata["bEditPage"] = true; 
	
		$fdata["bInlineEdit"] = true; 
	
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "deductionamount"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "deductionamount";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "Number");
	
		
		
		
		
		
		
		$vdata["DecimalDigits"] = 2;
	
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text field");
	
			
	
	


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
			$edata["HTML5InuptType"] = "number";
	
		$edata["EditParams"] = "";
			
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");	
								
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the user's search options list 
		$fdata["searchOptionsList"] = array();
		$fdata["searchOptionsList"][] = "Contains";
		$fdata["searchOptionsList"][] = "Equals";
		$fdata["searchOptionsList"][] = "Starts with";
		$fdata["searchOptionsList"][] = "More than";
		$fdata["searchOptionsList"][] = "Less than";
		$fdata["searchOptionsList"][] = "Between";
		$fdata["searchOptionsList"][] = "Empty";
		$fdata["searchOptionsList"][] = "NOT Contains";
		$fdata["searchOptionsList"][] = "NOT Equals";
		$fdata["searchOptionsList"][] = "NOT Starts with";
		$fdata["searchOptionsList"][] = "NOT More than";
		$fdata["searchOptionsList"][] = "NOT Less than";
		$fdata["searchOptionsList"][] = "NOT Between";
		$fdata["searchOptionsList"][] = "NOT Empty";
// the end of search options settings	

	

	
	$tdatadeductionsarchive["deductionamount"] = $fdata;
//	deductionreason
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 7;
	$fdata["strName"] = "deductionreason";
	$fdata["GoodName"] = "deductionreason";
	$fdata["ownerTable"] = "deductionsarchive";
	$fdata["Label"] = GetFieldLabel("deductionsarchive","deductionreason"); 
	$fdata["FieldType"] = 200;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		$fdata["bInlineAdd"] = true; 
	
		$fdata["bEditPage"] = true; 
	
		$fdata["bInlineEdit"] = true; 
	
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "deductionreason"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "deductionreason";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text field");
	
			
	
	


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
			$edata["HTML5InuptType"] = "text";
	
		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=50";
	
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the user's search options list 
		$fdata["searchOptionsList"] = array();
		$fdata["searchOptionsList"][] = "Contains";
		$fdata["searchOptionsList"][] = "Equals";
		$fdata["searchOptionsList"][] = "Starts with";
		$fdata["searchOptionsList"][] = "More than";
		$fdata["searchOptionsList"][] = "Less than";
		$fdata["searchOptionsList"][] = "Between";
		$fdata["searchOptionsList"][] = "Empty";
		$fdata["searchOptionsList"][] = "NOT Contains";
		$fdata["searchOptionsList"][] = "NOT Equals";
		$fdata["searchOptionsList"][] = "NOT Starts with";
		$fdata["searchOptionsList"][] = "NOT More than";
		$fdata["searchOptionsList"][] = "NOT Less than";
		$fdata["searchOptionsList"][] = "NOT Between";
		$fdata["searchOptionsList"][] = "NOT Empty";
// the end of search options settings	

	

	
	$tdatadeductionsarchive["deductionreason"] = $fdata;
//	newID
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 8;
	$fdata["strName"] = "newID";
	$fdata["GoodName"] = "newID";
	$fdata["ownerTable"] = "deductionsarchive";
	$fdata["Label"] = GetFieldLabel("deductionsarchive","newID"); 
	$fdata["FieldType"] = 3;
	
		
		$fdata["AutoInc"] = true;
	
		
				
		$fdata["bListPage"] = true; 
	
		
		
		
		
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "newID"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "newID";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text field");
	
			
	
	


		$edata["IsRequired"] = true; 
	
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
			$edata["HTML5InuptType"] = "number";
	
		$edata["EditParams"] = "";
			
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");	
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
			
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the default search options list
				$fdata["searchOptionsList"] = array("Equals", "More than", "Less than", "Between");
// the end of search options settings	

	

	
	$tdatadeductionsarchive["newID"] = $fdata;
//	duration
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 9;
	$fdata["strName"] = "duration";
	$fdata["GoodName"] = "duration";
	$fdata["ownerTable"] = "deductionsarchive";
	$fdata["Label"] = GetFieldLabel("deductionsarchive","duration"); 
	$fdata["FieldType"] = 200;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		$fdata["bInlineAdd"] = true; 
	
		$fdata["bEditPage"] = true; 
	
		$fdata["bInlineEdit"] = true; 
	
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "duration"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "duration";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Lookup wizard");
	
			
	
	
// Begin Lookup settings
		$edata["LookupType"] = 0;
		$edata["autoCompleteFieldsOnEdit"] = 0;
	$edata["autoCompleteFields"] = array();
		$edata["LCType"] = 3;
		
		$edata["HorizontalLookup"] = true;
	
		
		$edata["LookupValues"] = array();
	$edata["LookupValues"][] = "One Time";
	$edata["LookupValues"][] = "Start";
	$edata["LookupValues"][] = "Stop";

		$edata["Multiselect"] = true; 
	
		
// End Lookup Settings


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
		
		
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		$fdata["defaultSearchOption"] = "Equals";
	
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Empty");
// the end of search options settings	

	

	
	$tdatadeductionsarchive["duration"] = $fdata;

	
$tables_data["deductionsarchive"]=&$tdatadeductionsarchive;
$field_labels["deductionsarchive"] = &$fieldLabelsdeductionsarchive;
$fieldToolTips["deductionsarchive"] = &$fieldToolTipsdeductionsarchive;
$page_titles["deductionsarchive"] = &$pageTitlesdeductionsarchive;

// -----------------start  prepare master-details data arrays ------------------------------//
// tables which are detail tables for current table (master)
$detailsTablesData["deductionsarchive"] = array();
	
// tables which are master tables for current table (detail)
$masterTablesData["deductionsarchive"] = array();


// -----------------end  prepare master-details data arrays ------------------------------//

require_once(getabspath("classes/sql.php"));










function createSqlQuery_deductionsarchive()
{
$proto0=array();
$proto0["m_strHead"] = "SELECT";
$proto0["m_strFieldList"] = "ID,  `date`,  branch,  employeeidnumber,  employeename,  deductionamount,  deductionreason,  newID,  duration";
$proto0["m_strFrom"] = "FROM deductionsarchive";
$proto0["m_strWhere"] = "";
$proto0["m_strOrderBy"] = "ORDER BY `date` DESC, employeeidnumber, deductionreason";
$proto0["m_strTail"] = "";
			$proto0["cipherer"] = null;
$proto1=array();
$proto1["m_sql"] = "";
$proto1["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto1["m_column"]=$obj;
$proto1["m_contained"] = array();
$proto1["m_strCase"] = "";
$proto1["m_havingmode"] = false;
$proto1["m_inBrackets"] = false;
$proto1["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto1);

$proto0["m_where"] = $obj;
$proto3=array();
$proto3["m_sql"] = "";
$proto3["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto3["m_column"]=$obj;
$proto3["m_contained"] = array();
$proto3["m_strCase"] = "";
$proto3["m_havingmode"] = false;
$proto3["m_inBrackets"] = false;
$proto3["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto3);

$proto0["m_having"] = $obj;
$proto0["m_fieldlist"] = array();
						$proto5=array();
			$obj = new SQLField(array(
	"m_strName" => "ID",
	"m_strTable" => "deductionsarchive",
	"m_srcTableName" => "deductionsarchive"
));

$proto5["m_sql"] = "ID";
$proto5["m_srcTableName"] = "deductionsarchive";
$proto5["m_expr"]=$obj;
$proto5["m_alias"] = "";
$obj = new SQLFieldListItem($proto5);

$proto0["m_fieldlist"][]=$obj;
						$proto7=array();
			$obj = new SQLField(array(
	"m_strName" => "date",
	"m_strTable" => "deductionsarchive",
	"m_srcTableName" => "deductionsarchive"
));

$proto7["m_sql"] = "`date`";
$proto7["m_srcTableName"] = "deductionsarchive";
$proto7["m_expr"]=$obj;
$proto7["m_alias"] = "";
$obj = new SQLFieldListItem($proto7);

$proto0["m_fieldlist"][]=$obj;
						$proto9=array();
			$obj = new SQLField(array(
	"m_strName" => "branch",
	"m_strTable" => "deductionsarchive",
	"m_srcTableName" => "deductionsarchive"
));

$proto9["m_sql"] = "branch";
$proto9["m_srcTableName"] = "deductionsarchive";
$proto9["m_expr"]=$obj;
$proto9["m_alias"] = "";
$obj = new SQLFieldListItem($proto9);

$proto0["m_fieldlist"][]=$obj;
						$proto11=array();
			$obj = new SQLField(array(
	"m_strName" => "employeeidnumber",
	"m_strTable" => "deductionsarchive",
	"m_srcTableName" => "deductionsarchive"
));

$proto11["m_sql"] = "employeeidnumber";
$proto11["m_srcTableName"] = "deductionsarchive";
$proto11["m_expr"]=$obj;
$proto11["m_alias"] = "";
$obj = new SQLFieldListItem($proto11);

$proto0["m_fieldlist"][]=$obj;
						$proto13=array();
			$obj = new SQLField(array(
	"m_strName" => "employeename",
	"m_strTable" => "deductionsarchive",
	"m_srcTableName" => "deductionsarchive"
));

$proto13["m_sql"] = "employeename";
$proto13["m_srcTableName"] = "deductionsarchive";
$proto13["m_expr"]=$obj;
$proto13["m_alias"] = "";
$obj = new SQLFieldListItem($proto13);

$proto0["m_fieldlist"][]=$obj;
						$proto15=array();
			$obj = new SQLField(array(
	"m_strName" => "deductionamount",
	"m_strTable" => "deductionsarchive",
	"m_srcTableName" => "deductionsarchive"
));

$proto15["m_sql"] = "deductionamount";
$proto15["m_srcTableName"] = "deductionsarchive";
$proto15["m_expr"]=$obj;
$proto15["m_alias"] = "";
$obj = new SQLFieldListItem($proto15);

$proto0["m_fieldlist"][]=$obj;
						$proto17=array();
			$obj = new SQLField(array(
	"m_strName" => "deductionreason",
	"m_strTable" => "deductionsarchive",
	"m_srcTableName" => "deductionsarchive"
));

$proto17["m_sql"] = "deductionreason";
$proto17["m_srcTableName"] = "deductionsarchive";
$proto17["m_expr"]=$obj;
$proto17["m_alias"] = "";
$obj = new SQLFieldListItem($proto17);

$proto0["m_fieldlist"][]=$obj;
						$proto19=array();
			$obj = new SQLField(array(
	"m_strName" => "newID",
	"m_strTable" => "deductionsarchive",
	"m_srcTableName" => "deductionsarchive"
));

$proto19["m_sql"] = "newID";
$proto19["m_srcTableName"] = "deductionsarchive";
$proto19["m_expr"]=$obj;
$proto19["m_alias"] = "";
$obj = new SQLFieldListItem($proto19);

$proto0["m_fieldlist"][]=$obj;
						$proto21=array();
			$obj = new SQLField(array(
	"m_strName" => "duration",
	"m_strTable" => "deductionsarchive",
	"m_srcTableName" => "deductionsarchive"
));

$proto21["m_sql"] = "duration";
$proto21["m_srcTableName"] = "deductionsarchive";
$proto21["m_expr"]=$obj;
$proto21["m_alias"] = "";
$obj = new SQLFieldListItem($proto21);

$proto0["m_fieldlist"][]=$obj;
$proto0["m_fromlist"] = array();
												$proto23=array();
$proto23["m_link"] = "SQLL_MAIN";
			$proto24=array();
$proto24["m_strName"] = "deductionsarchive";
$proto24["m_srcTableName"] = "deductionsarchive";
$proto24["m_columns"] = array();
$proto24["m_columns"][] = "newID";
$proto24["m_columns"][] = "ID";
$proto24["m_columns"][] = "date";
$proto24["m_columns"][] = "branch";
$proto24["m_columns"][] = "employeeidnumber";
$proto24["m_columns"][] = "employeename";
$proto24["m_columns"][] = "deductionamount";
$proto24["m_columns"][] = "deductionreason";
$proto24["m_columns"][] = "duration";
$obj = new SQLTable($proto24);

$proto23["m_table"] = $obj;
$proto23["m_sql"] = "deductionsarchive";
$proto23["m_alias"] = "";
$proto23["m_srcTableName"] = "deductionsarchive";
$proto25=array();
$proto25["m_sql"] = "";
$proto25["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto25["m_column"]=$obj;
$proto25["m_contained"] = array();
$proto25["m_strCase"] = "";
$proto25["m_havingmode"] = false;
$proto25["m_inBrackets"] = false;
$proto25["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto25);

$proto23["m_joinon"] = $obj;
$obj = new SQLFromListItem($proto23);

$proto0["m_fromlist"][]=$obj;
$proto0["m_groupby"] = array();
$proto0["m_orderby"] = array();
												$proto27=array();
						$obj = new SQLField(array(
	"m_strName" => "date",
	"m_strTable" => "deductionsarchive",
	"m_srcTableName" => "deductionsarchive"
));

$proto27["m_column"]=$obj;
$proto27["m_bAsc"] = 0;
$proto27["m_nColumn"] = 0;
$obj = new SQLOrderByItem($proto27);

$proto0["m_orderby"][]=$obj;					
												$proto29=array();
						$obj = new SQLField(array(
	"m_strName" => "employeeidnumber",
	"m_strTable" => "deductionsarchive",
	"m_srcTableName" => "deductionsarchive"
));

$proto29["m_column"]=$obj;
$proto29["m_bAsc"] = 1;
$proto29["m_nColumn"] = 0;
$obj = new SQLOrderByItem($proto29);

$proto0["m_orderby"][]=$obj;					
												$proto31=array();
						$obj = new SQLField(array(
	"m_strName" => "deductionreason",
	"m_strTable" => "deductionsarchive",
	"m_srcTableName" => "deductionsarchive"
));

$proto31["m_column"]=$obj;
$proto31["m_bAsc"] = 1;
$proto31["m_nColumn"] = 0;
$obj = new SQLOrderByItem($proto31);

$proto0["m_orderby"][]=$obj;					
$proto0["m_srcTableName"]="deductionsarchive";		
$obj = new SQLQuery($proto0);

	return $obj;
}
$queryData_deductionsarchive = createSqlQuery_deductionsarchive();


	
									
	
$tdatadeductionsarchive[".sqlquery"] = $queryData_deductionsarchive;

include_once(getabspath("include/deductionsarchive_events.php"));
$tableEvents["deductionsarchive"] = new eventclass_deductionsarchive;
$tdatadeductionsarchive[".hasEvents"] = true;

?>