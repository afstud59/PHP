<?php
$strTableName="Deductions Archive Report";
$_SESSION["OwnerID"] = $_SESSION["_".$strTableName."_OwnerID"];

$strOriginalTableName="deductionsarchive";

$gstrOrderBy="ORDER BY deductionreason, employeeidnumber";
if(strlen($gstrOrderBy) && strtolower(substr($gstrOrderBy,0,8))!="order by")
	$gstrOrderBy="order by ".$gstrOrderBy;

// alias for 'SQLQuery' object
$gSettings = new ProjectSettings("Deductions Archive Report");
$gQuery = $gSettings->getSQLQuery();
$eventObj = &$tableEvents["Deductions Archive Report"];

$reportCaseSensitiveGroupFields = false;

$gstrSQL = $gQuery->gSQLWhere("");

?>