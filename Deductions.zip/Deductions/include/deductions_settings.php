<?php

require_once(getabspath("classes/cipherer.php"));









$tdatadeductions = array();	

	$tdatadeductions[".truncateText"] = true;

	$tdatadeductions[".NumberOfChars"] = 80; 

	$tdatadeductions[".ShortName"] = "deductions";

	$tdatadeductions[".OwnerID"] = "branch";

	$tdatadeductions[".OriginalTable"] = "deductions";



//	field labels

$fieldLabelsdeductions = array();

$fieldToolTipsdeductions = array();

$pageTitlesdeductions = array();



if(mlang_getcurrentlang()=="English")

{

	$fieldLabelsdeductions["English"] = array();

	$fieldToolTipsdeductions["English"] = array();

	$pageTitlesdeductions["English"] = array();

	$fieldLabelsdeductions["English"]["date"] = "Date";

	$fieldToolTipsdeductions["English"]["date"] = "";

	$fieldLabelsdeductions["English"]["branch"] = "Branch";

	$fieldToolTipsdeductions["English"]["branch"] = "";

	$fieldLabelsdeductions["English"]["employeeidnumber"] = "Employee ID Number";

	$fieldToolTipsdeductions["English"]["employeeidnumber"] = "";

	$fieldLabelsdeductions["English"]["employeename"] = "Employee Name";

	$fieldToolTipsdeductions["English"]["employeename"] = "";

	$fieldLabelsdeductions["English"]["deductionamount"] = "Deduction Amount";

	$fieldToolTipsdeductions["English"]["deductionamount"] = "";

	$fieldLabelsdeductions["English"]["deductionreason"] = "Deduction Reason";

	$fieldToolTipsdeductions["English"]["deductionreason"] = "";

	$fieldLabelsdeductions["English"]["ID"] = "ID";

	$fieldToolTipsdeductions["English"]["ID"] = "";

	$fieldLabelsdeductions["English"]["duration"] = "Duration";

	$fieldToolTipsdeductions["English"]["duration"] = "";

	if (count($fieldToolTipsdeductions["English"]))

		$tdatadeductions[".isUseToolTips"] = true;

}

if(mlang_getcurrentlang()=="")

{

	$fieldLabelsdeductions[""] = array();

	$fieldToolTipsdeductions[""] = array();

	$pageTitlesdeductions[""] = array();

	$fieldLabelsdeductions[""]["ID"] = "ID";

	$fieldToolTipsdeductions[""]["ID"] = "";

	if (count($fieldToolTipsdeductions[""]))

		$tdatadeductions[".isUseToolTips"] = true;

}

	

	

	$tdatadeductions[".NCSearch"] = true;







$tdatadeductions[".shortTableName"] = "deductions";

$tdatadeductions[".nSecOptions"] = 1;

$tdatadeductions[".recsPerRowList"] = 1;

$tdatadeductions[".recsPerRowPrint"] = 1;

$tdatadeductions[".mainTableOwnerID"] = "branch";

$tdatadeductions[".moveNext"] = 1;

$tdatadeductions[".entityType"] = 0;



$tdatadeductions[".strOriginalTableName"] = "deductions";









$tdatadeductions[".showAddInPopup"] = false;



$tdatadeductions[".showEditInPopup"] = false;



$tdatadeductions[".showViewInPopup"] = false;



//page's base css files names

$popupPagesLayoutNames = array();

$tdatadeductions[".popupPagesLayoutNames"] = $popupPagesLayoutNames;





$tdatadeductions[".fieldsForRegister"] = array();



$tdatadeductions[".listAjax"] = false;



	$tdatadeductions[".audit"] = true;



	$tdatadeductions[".locking"] = false;



$tdatadeductions[".edit"] = true;

$tdatadeductions[".afterEditAction"] = 1;

$tdatadeductions[".closePopupAfterEdit"] = 1;

$tdatadeductions[".afterEditActionDetTable"] = "";



$tdatadeductions[".add"] = true;

$tdatadeductions[".afterAddAction"] = 1;

$tdatadeductions[".closePopupAfterAdd"] = 1;

$tdatadeductions[".afterAddActionDetTable"] = "";



$tdatadeductions[".list"] = true;



$tdatadeductions[".inlineEdit"] = true;

$tdatadeductions[".inlineAdd"] = true;

$tdatadeductions[".view"] = true;



$tdatadeductions[".import"] = true;



$tdatadeductions[".exportTo"] = true;



$tdatadeductions[".printFriendly"] = true;



$tdatadeductions[".delete"] = true;



$tdatadeductions[".showSimpleSearchOptions"] = false;



// search Saving settings

$tdatadeductions[".searchSaving"] = false;

//



$tdatadeductions[".showSearchPanel"] = true;

		$tdatadeductions[".flexibleSearch"] = true;		



if (isMobile())

	$tdatadeductions[".isUseAjaxSuggest"] = false;

else 

	$tdatadeductions[".isUseAjaxSuggest"] = true;



$tdatadeductions[".rowHighlite"] = true;







$tdatadeductions[".addPageEvents"] = false;



// use timepicker for search panel

$tdatadeductions[".isUseTimeForSearch"] = false;











$tdatadeductions[".allSearchFields"] = array();

$tdatadeductions[".filterFields"] = array();

$tdatadeductions[".requiredSearchFields"] = array();



$tdatadeductions[".allSearchFields"][] = "ID";

	$tdatadeductions[".allSearchFields"][] = "date";

	$tdatadeductions[".allSearchFields"][] = "branch";

	$tdatadeductions[".allSearchFields"][] = "employeeidnumber";

	$tdatadeductions[".allSearchFields"][] = "employeename";

	$tdatadeductions[".allSearchFields"][] = "deductionamount";

	$tdatadeductions[".allSearchFields"][] = "deductionreason";

	$tdatadeductions[".allSearchFields"][] = "duration";

	



$tdatadeductions[".googleLikeFields"] = array();

$tdatadeductions[".googleLikeFields"][] = "date";

$tdatadeductions[".googleLikeFields"][] = "branch";

$tdatadeductions[".googleLikeFields"][] = "employeeidnumber";

$tdatadeductions[".googleLikeFields"][] = "employeename";

$tdatadeductions[".googleLikeFields"][] = "deductionamount";

$tdatadeductions[".googleLikeFields"][] = "deductionreason";

$tdatadeductions[".googleLikeFields"][] = "ID";

$tdatadeductions[".googleLikeFields"][] = "duration";





$tdatadeductions[".advSearchFields"] = array();

$tdatadeductions[".advSearchFields"][] = "ID";

$tdatadeductions[".advSearchFields"][] = "date";

$tdatadeductions[".advSearchFields"][] = "branch";

$tdatadeductions[".advSearchFields"][] = "employeeidnumber";

$tdatadeductions[".advSearchFields"][] = "employeename";

$tdatadeductions[".advSearchFields"][] = "deductionamount";

$tdatadeductions[".advSearchFields"][] = "deductionreason";

$tdatadeductions[".advSearchFields"][] = "duration";



$tdatadeductions[".tableType"] = "list";



$tdatadeductions[".printerPageOrientation"] = 0;

$tdatadeductions[".nPrinterPageScale"] = 100;



$tdatadeductions[".nPrinterSplitRecords"] = 40;



$tdatadeductions[".nPrinterPDFSplitRecords"] = 40;







$tdatadeductions[".geocodingEnabled"] = false;









	











// view page pdf



// print page pdf





$tdatadeductions[".pageSize"] = 50;



$tdatadeductions[".warnLeavingPages"] = true;







$tstrOrderBy = "ORDER BY employeeidnumber";

if(strlen($tstrOrderBy) && strtolower(substr($tstrOrderBy,0,8))!="order by")

	$tstrOrderBy = "order by ".$tstrOrderBy;

$tdatadeductions[".strOrderBy"] = $tstrOrderBy;



$tdatadeductions[".orderindexes"] = array();

$tdatadeductions[".orderindexes"][] = array(3, (1 ? "ASC" : "DESC"), "employeeidnumber");



$tdatadeductions[".sqlHead"] = "SELECT `date`,  branch,  employeeidnumber,  employeename,  deductionamount,  deductionreason,  ID,  duration";

$tdatadeductions[".sqlFrom"] = "FROM deductions";

$tdatadeductions[".sqlWhereExpr"] = "";

$tdatadeductions[".sqlTail"] = "";



















//fill array of records per page for list and report without group fields

$arrRPP = array();

$arrRPP[] = 10;

$arrRPP[] = 20;

$arrRPP[] = 30;

$arrRPP[] = 50;

$arrRPP[] = 100;

$arrRPP[] = 500;

$arrRPP[] = -1;

$tdatadeductions[".arrRecsPerPage"] = $arrRPP;



//fill array of groups per page for report with group fields

$arrGPP = array();

$arrGPP[] = 1;

$arrGPP[] = 3;

$arrGPP[] = 5;

$arrGPP[] = 10;

$arrGPP[] = 50;

$arrGPP[] = 100;

$arrGPP[] = -1;

$tdatadeductions[".arrGroupsPerPage"] = $arrGPP;



$tdatadeductions[".highlightSearchResults"] = true;



$tableKeysdeductions = array();

$tableKeysdeductions[] = "ID";

$tdatadeductions[".Keys"] = $tableKeysdeductions;



$tdatadeductions[".listFields"] = array();

$tdatadeductions[".listFields"][] = "ID";

$tdatadeductions[".listFields"][] = "date";

$tdatadeductions[".listFields"][] = "branch";

$tdatadeductions[".listFields"][] = "employeeidnumber";

$tdatadeductions[".listFields"][] = "employeename";

$tdatadeductions[".listFields"][] = "deductionamount";

$tdatadeductions[".listFields"][] = "deductionreason";

$tdatadeductions[".listFields"][] = "duration";



$tdatadeductions[".hideMobileList"] = array();





$tdatadeductions[".viewFields"] = array();

$tdatadeductions[".viewFields"][] = "ID";

$tdatadeductions[".viewFields"][] = "date";

$tdatadeductions[".viewFields"][] = "branch";

$tdatadeductions[".viewFields"][] = "employeeidnumber";

$tdatadeductions[".viewFields"][] = "employeename";

$tdatadeductions[".viewFields"][] = "deductionamount";

$tdatadeductions[".viewFields"][] = "deductionreason";

$tdatadeductions[".viewFields"][] = "duration";



$tdatadeductions[".addFields"] = array();

$tdatadeductions[".addFields"][] = "date";

$tdatadeductions[".addFields"][] = "branch";

$tdatadeductions[".addFields"][] = "employeeidnumber";

$tdatadeductions[".addFields"][] = "employeename";

$tdatadeductions[".addFields"][] = "deductionamount";

$tdatadeductions[".addFields"][] = "deductionreason";

$tdatadeductions[".addFields"][] = "duration";



$tdatadeductions[".masterListFields"] = array();

$tdatadeductions[".masterListFields"][] = "date";

$tdatadeductions[".masterListFields"][] = "branch";

$tdatadeductions[".masterListFields"][] = "employeeidnumber";

$tdatadeductions[".masterListFields"][] = "employeename";

$tdatadeductions[".masterListFields"][] = "deductionamount";

$tdatadeductions[".masterListFields"][] = "deductionreason";

$tdatadeductions[".masterListFields"][] = "ID";

$tdatadeductions[".masterListFields"][] = "duration";



$tdatadeductions[".inlineAddFields"] = array();

$tdatadeductions[".inlineAddFields"][] = "date";

$tdatadeductions[".inlineAddFields"][] = "branch";

$tdatadeductions[".inlineAddFields"][] = "employeeidnumber";

$tdatadeductions[".inlineAddFields"][] = "employeename";

$tdatadeductions[".inlineAddFields"][] = "deductionamount";

$tdatadeductions[".inlineAddFields"][] = "deductionreason";

$tdatadeductions[".inlineAddFields"][] = "duration";



$tdatadeductions[".editFields"] = array();

$tdatadeductions[".editFields"][] = "date";

$tdatadeductions[".editFields"][] = "branch";

$tdatadeductions[".editFields"][] = "employeeidnumber";

$tdatadeductions[".editFields"][] = "employeename";

$tdatadeductions[".editFields"][] = "deductionamount";

$tdatadeductions[".editFields"][] = "deductionreason";

$tdatadeductions[".editFields"][] = "duration";



$tdatadeductions[".inlineEditFields"] = array();

$tdatadeductions[".inlineEditFields"][] = "date";

$tdatadeductions[".inlineEditFields"][] = "branch";

$tdatadeductions[".inlineEditFields"][] = "employeeidnumber";

$tdatadeductions[".inlineEditFields"][] = "employeename";

$tdatadeductions[".inlineEditFields"][] = "deductionamount";

$tdatadeductions[".inlineEditFields"][] = "deductionreason";

$tdatadeductions[".inlineEditFields"][] = "duration";



$tdatadeductions[".exportFields"] = array();

$tdatadeductions[".exportFields"][] = "date";

$tdatadeductions[".exportFields"][] = "branch";

$tdatadeductions[".exportFields"][] = "employeeidnumber";

$tdatadeductions[".exportFields"][] = "employeename";

$tdatadeductions[".exportFields"][] = "deductionamount";

$tdatadeductions[".exportFields"][] = "deductionreason";

$tdatadeductions[".exportFields"][] = "duration";



$tdatadeductions[".importFields"] = array();

$tdatadeductions[".importFields"][] = "date";

$tdatadeductions[".importFields"][] = "branch";

$tdatadeductions[".importFields"][] = "employeeidnumber";

$tdatadeductions[".importFields"][] = "employeename";

$tdatadeductions[".importFields"][] = "deductionamount";

$tdatadeductions[".importFields"][] = "deductionreason";

$tdatadeductions[".importFields"][] = "duration";



$tdatadeductions[".printFields"] = array();

$tdatadeductions[".printFields"][] = "ID";

$tdatadeductions[".printFields"][] = "date";

$tdatadeductions[".printFields"][] = "branch";

$tdatadeductions[".printFields"][] = "employeeidnumber";

$tdatadeductions[".printFields"][] = "employeename";

$tdatadeductions[".printFields"][] = "deductionamount";

$tdatadeductions[".printFields"][] = "deductionreason";

$tdatadeductions[".printFields"][] = "duration";



//	date

//	Custom field settings

	$fdata = array();

	$fdata["Index"] = 1;

	$fdata["strName"] = "date";

	$fdata["GoodName"] = "date";

	$fdata["ownerTable"] = "deductions";

	$fdata["Label"] = GetFieldLabel("deductions","date"); 

	$fdata["FieldType"] = 7;

	

		

		

		

				

		$fdata["bListPage"] = true; 

	

		$fdata["bAddPage"] = true; 

	

		$fdata["bInlineAdd"] = true; 

	

		$fdata["bEditPage"] = true; 

	

		$fdata["bInlineEdit"] = true; 

	

		$fdata["bViewPage"] = true; 

	

		$fdata["bAdvancedSearch"] = true; 

	

		$fdata["bPrinterPage"] = true; 

	

		$fdata["bExportPage"] = true; 

	

		$fdata["strField"] = "date"; 

	

		$fdata["isSQLExpression"] = true;

	$fdata["FullName"] = "`date`";

	

		

		

				$fdata["FieldPermissions"] = true;

	

				$fdata["UploadFolder"] = "files";

		

//  Begin View Formats

	$fdata["ViewFormats"] = array();

	

	$vdata = array("ViewFormat" => "Short Date");

	

		

		

		

		

		

		

		

		

		

		

		

		$vdata["NeedEncode"] = true;

	

	$fdata["ViewFormats"]["view"] = $vdata;

	$vdata = array("ViewFormat" => "Short Date");

	

		

		

		

		

		

		

		

		

		

		

		

		$vdata["NeedEncode"] = true;

	

	$fdata["ViewFormats"]["list"] = $vdata;

	$vdata = array("ViewFormat" => "Short Date");

	

		

		

		

		

		

		

		

		

		

		

		

		$vdata["NeedEncode"] = true;

	

	$fdata["ViewFormats"]["print"] = $vdata;

	$vdata = array("ViewFormat" => "Short Date");

	

		

		

		

		

		

		

		

		

		

		

		

		$vdata["NeedEncode"] = true;

	

	$fdata["ViewFormats"]["export"] = $vdata;

//  End View Formats



//	Begin Edit Formats 	

	$fdata["EditFormats"] = array();

	

	$edata = array("EditFormat" => "Date");

	

			

	

	





		$edata["IsRequired"] = true; 

	

		

		

		

			$edata["acceptFileTypes"] = ".+$";

	

		$edata["maxNumberOfFiles"] = 1;

	

		

		

		$edata["DateEditType"] = 0; 

	$edata["InitialYearFactor"] = 100; 

	$edata["LastYearFactor"] = 10; 

	

		

		

		

		$edata["controlWidth"] = 200;

	

//	Begin validation

	$edata["validateAs"] = array();

	$edata["validateAs"]["basicValidate"] = array();

	$edata["validateAs"]["customMessages"] = array();

						$edata["validateAs"]["basicValidate"][] = "IsRequired";

			

		

	//	End validation

	

		

				

		

	

		

	$fdata["EditFormats"]["edit"] = $edata;

	$edata = array("EditFormat" => "Date");

	

			

	

	





		$edata["IsRequired"] = true; 

	

		

		

		

			$edata["acceptFileTypes"] = ".+$";

	

		$edata["maxNumberOfFiles"] = 1;

	

		

		

		$edata["DateEditType"] = 0; 

	$edata["InitialYearFactor"] = 100; 

	$edata["LastYearFactor"] = 10; 

	

		

		

		

		$edata["controlWidth"] = 200;

	

//	Begin validation

	$edata["validateAs"] = array();

	$edata["validateAs"]["basicValidate"] = array();

	$edata["validateAs"]["customMessages"] = array();

						$edata["validateAs"]["basicValidate"][] = "IsRequired";

			

		

	//	End validation

	

		

				

		

	

		

	$fdata["EditFormats"]["add"] = $edata;

	$edata = array("EditFormat" => "Date");

	

			

	

	





		$edata["IsRequired"] = true; 

	

		

		

		

			$edata["acceptFileTypes"] = ".+$";

	

		$edata["maxNumberOfFiles"] = 1;

	

		

		

		$edata["DateEditType"] = 0; 

	$edata["InitialYearFactor"] = 100; 

	$edata["LastYearFactor"] = 10; 

	

		

		

		

		$edata["controlWidth"] = 200;

	

//	Begin validation

	$edata["validateAs"] = array();

	$edata["validateAs"]["basicValidate"] = array();

	$edata["validateAs"]["customMessages"] = array();

						$edata["validateAs"]["basicValidate"][] = "IsRequired";

			

		

	//	End validation

	

		

				

		

	

		

	$fdata["EditFormats"]["search"] = $edata;

//	End Edit Formats

	

	

	$fdata["isSeparate"] = true;

	

	

	

	

// the field's search options settings

		

			// the default search options list

				$fdata["searchOptionsList"] = array("Equals", "More than", "Less than", "Between");

// the end of search options settings	



	



	

	$tdatadeductions["date"] = $fdata;

//	branch

//	Custom field settings

	$fdata = array();

	$fdata["Index"] = 2;

	$fdata["strName"] = "branch";

	$fdata["GoodName"] = "branch";

	$fdata["ownerTable"] = "deductions";

	$fdata["Label"] = GetFieldLabel("deductions","branch"); 

	$fdata["FieldType"] = 200;

	

		

		

		

				

		$fdata["bListPage"] = true; 

	

		$fdata["bAddPage"] = true; 

	

		$fdata["bInlineAdd"] = true; 

	

		$fdata["bEditPage"] = true; 

	

		$fdata["bInlineEdit"] = true; 

	

		$fdata["bViewPage"] = true; 

	

		$fdata["bAdvancedSearch"] = true; 

	

		$fdata["bPrinterPage"] = true; 

	

		$fdata["bExportPage"] = true; 

	

		$fdata["strField"] = "branch"; 

	

		$fdata["isSQLExpression"] = true;

	$fdata["FullName"] = "branch";

	

		

		

				$fdata["FieldPermissions"] = true;

	

				$fdata["UploadFolder"] = "files";

		

//  Begin View Formats

	$fdata["ViewFormats"] = array();

	

	$vdata = array("ViewFormat" => "");

	

		

		

		

		

		

		

		

		

		

		

		

		$vdata["NeedEncode"] = true;

	

	$fdata["ViewFormats"]["view"] = $vdata;

	$vdata = array("ViewFormat" => "");

	

		

		

		

		

		

		

		

		

		

		

		

		$vdata["NeedEncode"] = true;

	

	$fdata["ViewFormats"]["list"] = $vdata;

	$vdata = array("ViewFormat" => "");

	

		

		

		

		

		

		

		

		

		

		

		

		$vdata["NeedEncode"] = true;

	

	$fdata["ViewFormats"]["print"] = $vdata;

	$vdata = array("ViewFormat" => "");

	

		

		

		

		

		

		

		

		

		

		

		

		$vdata["NeedEncode"] = true;

	

	$fdata["ViewFormats"]["export"] = $vdata;

//  End View Formats



//	Begin Edit Formats 	

	$fdata["EditFormats"] = array();

	

	$edata = array("EditFormat" => "Text field");

	

			

	

	





		$edata["IsRequired"] = true; 

	

		

		

		

			$edata["acceptFileTypes"] = ".+$";

	

		$edata["maxNumberOfFiles"] = 1;

	

		

		

		

		

			$edata["HTML5InuptType"] = "text";

	

		$edata["EditParams"] = "";

			$edata["EditParams"].= " maxlength=50";

	

		$edata["controlWidth"] = 200;

	

//	Begin validation

	$edata["validateAs"] = array();

	$edata["validateAs"]["basicValidate"] = array();

	$edata["validateAs"]["customMessages"] = array();

						$edata["validateAs"]["basicValidate"][] = "IsRequired";

			

		

	//	End validation

	

		

				

		

	

		

	$fdata["EditFormats"]["edit"] = $edata;

	$edata = array("EditFormat" => "Text field");

	

			

	

	





		$edata["IsRequired"] = true; 

	

		

		

		

			$edata["acceptFileTypes"] = ".+$";

	

		$edata["maxNumberOfFiles"] = 1;

	

		

		

		

		

			$edata["HTML5InuptType"] = "text";

	

		$edata["EditParams"] = "";

			$edata["EditParams"].= " maxlength=50";

	

		$edata["controlWidth"] = 200;

	

//	Begin validation

	$edata["validateAs"] = array();

	$edata["validateAs"]["basicValidate"] = array();

	$edata["validateAs"]["customMessages"] = array();

						$edata["validateAs"]["basicValidate"][] = "IsRequired";

			

		

	//	End validation

	

		

				

		

	

		

	$fdata["EditFormats"]["add"] = $edata;

	$edata = array("EditFormat" => "Text field");

	

			

	

	





		$edata["IsRequired"] = true; 

	

		

		

		

			$edata["acceptFileTypes"] = ".+$";

	

		$edata["maxNumberOfFiles"] = 1;

	

		

		

		

		

			$edata["HTML5InuptType"] = "text";

	

		$edata["EditParams"] = "";

			$edata["EditParams"].= " maxlength=50";

	

		$edata["controlWidth"] = 200;

	

//	Begin validation

	$edata["validateAs"] = array();

	$edata["validateAs"]["basicValidate"] = array();

	$edata["validateAs"]["customMessages"] = array();

						$edata["validateAs"]["basicValidate"][] = "IsRequired";

			

		

	//	End validation

	

		

				

		

	

		

	$fdata["EditFormats"]["search"] = $edata;

//	End Edit Formats

	

	

	$fdata["isSeparate"] = true;

	

	

	

	

// the field's search options settings

		

			// the default search options list

				$fdata["searchOptionsList"] = array("Contains", "Equals", "Empty");

// the end of search options settings	



	



	

	$tdatadeductions["branch"] = $fdata;

//	employeeidnumber

//	Custom field settings

	$fdata = array();

	$fdata["Index"] = 3;

	$fdata["strName"] = "employeeidnumber";

	$fdata["GoodName"] = "employeeidnumber";

	$fdata["ownerTable"] = "deductions";

	$fdata["Label"] = GetFieldLabel("deductions","employeeidnumber"); 

	$fdata["FieldType"] = 3;

	

		

		

		

				

		$fdata["bListPage"] = true; 

	

		$fdata["bAddPage"] = true; 

	

		$fdata["bInlineAdd"] = true; 

	

		$fdata["bEditPage"] = true; 

	

		$fdata["bInlineEdit"] = true; 

	

		$fdata["bViewPage"] = true; 

	

		$fdata["bAdvancedSearch"] = true; 

	

		$fdata["bPrinterPage"] = true; 

	

		$fdata["bExportPage"] = true; 

	

		$fdata["strField"] = "employeeidnumber"; 

	

		$fdata["isSQLExpression"] = true;

	$fdata["FullName"] = "employeeidnumber";

	

		

		

				$fdata["FieldPermissions"] = true;

	

				$fdata["UploadFolder"] = "files";

		

//  Begin View Formats

	$fdata["ViewFormats"] = array();

	

	$vdata = array("ViewFormat" => "");

	

		

		

		

		

		

		

		

		

		

		

		

		$vdata["NeedEncode"] = true;

	

	$fdata["ViewFormats"]["view"] = $vdata;

//  End View Formats



//	Begin Edit Formats 	

	$fdata["EditFormats"] = array();

	

	$edata = array("EditFormat" => "Text field");

	

			

	

	





		$edata["IsRequired"] = true; 

	

		

		

		

			$edata["acceptFileTypes"] = ".+$";

	

		$edata["maxNumberOfFiles"] = 1;

	

		

		

		

		

			$edata["HTML5InuptType"] = "text";

	

		$edata["EditParams"] = "";

			$edata["EditParams"].= " maxlength=6";

	

		$edata["controlWidth"] = 200;

	

//	Begin validation

	$edata["validateAs"] = array();

	$edata["validateAs"]["basicValidate"] = array();

	$edata["validateAs"]["customMessages"] = array();

				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");	

						$edata["validateAs"]["basicValidate"][] = "IsRequired";

			

		

	//	End validation

	

		

				

		

	

		

	$fdata["EditFormats"]["edit"] = $edata;

//	End Edit Formats

	

	

	$fdata["isSeparate"] = false;

	

	

	

	

// the field's search options settings

		

			// the default search options list

				$fdata["searchOptionsList"] = array("Equals", "More than", "Less than", "Between");

// the end of search options settings	



	



	

	$tdatadeductions["employeeidnumber"] = $fdata;

//	employeename

//	Custom field settings

	$fdata = array();

	$fdata["Index"] = 4;

	$fdata["strName"] = "employeename";

	$fdata["GoodName"] = "employeename";

	$fdata["ownerTable"] = "deductions";

	$fdata["Label"] = GetFieldLabel("deductions","employeename"); 

	$fdata["FieldType"] = 200;

	

		

		

		

				

		$fdata["bListPage"] = true; 

	

		$fdata["bAddPage"] = true; 

	

		$fdata["bInlineAdd"] = true; 

	

		$fdata["bEditPage"] = true; 

	

		$fdata["bInlineEdit"] = true; 

	

		$fdata["bViewPage"] = true; 

	

		$fdata["bAdvancedSearch"] = true; 

	

		$fdata["bPrinterPage"] = true; 

	

		$fdata["bExportPage"] = true; 

	

		$fdata["strField"] = "employeename"; 

	

		$fdata["isSQLExpression"] = true;

	$fdata["FullName"] = "employeename";

	

		

		

				$fdata["FieldPermissions"] = true;

	

				$fdata["UploadFolder"] = "files";

		

//  Begin View Formats

	$fdata["ViewFormats"] = array();

	

	$vdata = array("ViewFormat" => "");

	

		

		

		

		

		

		

		

		

		

		

		

		$vdata["NeedEncode"] = true;

	

	$fdata["ViewFormats"]["view"] = $vdata;

//  End View Formats



//	Begin Edit Formats 	

	$fdata["EditFormats"] = array();

	

	$edata = array("EditFormat" => "Text field");

	

			

	

	





		$edata["IsRequired"] = true; 

	

		

		

		

			$edata["acceptFileTypes"] = ".+$";

	

		$edata["maxNumberOfFiles"] = 1;

	

		

		

		

		

			$edata["HTML5InuptType"] = "text";

	

		$edata["EditParams"] = "";

			$edata["EditParams"].= " maxlength=50";

	

		$edata["controlWidth"] = 200;

	

//	Begin validation

	$edata["validateAs"] = array();

	$edata["validateAs"]["basicValidate"] = array();

	$edata["validateAs"]["customMessages"] = array();

						$edata["validateAs"]["basicValidate"][] = "IsRequired";

			

		

	//	End validation

	

		

				

		

	

		

	$fdata["EditFormats"]["edit"] = $edata;

//	End Edit Formats

	

	

	$fdata["isSeparate"] = false;

	

	

	

	

// the field's search options settings

		

			// the default search options list

				$fdata["searchOptionsList"] = array("Contains", "Equals", "Empty");

// the end of search options settings	



	



	

	$tdatadeductions["employeename"] = $fdata;

//	deductionamount

//	Custom field settings

	$fdata = array();

	$fdata["Index"] = 5;

	$fdata["strName"] = "deductionamount";

	$fdata["GoodName"] = "deductionamount";

	$fdata["ownerTable"] = "deductions";

	$fdata["Label"] = GetFieldLabel("deductions","deductionamount"); 

	$fdata["FieldType"] = 14;

	

		

		

		

				

		$fdata["bListPage"] = true; 

	

		$fdata["bAddPage"] = true; 

	

		$fdata["bInlineAdd"] = true; 

	

		$fdata["bEditPage"] = true; 

	

		$fdata["bInlineEdit"] = true; 

	

		$fdata["bViewPage"] = true; 

	

		$fdata["bAdvancedSearch"] = true; 

	

		$fdata["bPrinterPage"] = true; 

	

		$fdata["bExportPage"] = true; 

	

		$fdata["strField"] = "deductionamount"; 

	

		$fdata["isSQLExpression"] = true;

	$fdata["FullName"] = "deductionamount";

	

		

		

				$fdata["FieldPermissions"] = true;

	

				$fdata["UploadFolder"] = "files";

		

//  Begin View Formats

	$fdata["ViewFormats"] = array();

	

	$vdata = array("ViewFormat" => "Currency");

	

		

		

		

		

		

		

		

		

		

		

		

		$vdata["NeedEncode"] = true;

	

	$fdata["ViewFormats"]["view"] = $vdata;

//  End View Formats



//	Begin Edit Formats 	

	$fdata["EditFormats"] = array();

	

	$edata = array("EditFormat" => "Text field");

	

			

	

	





		$edata["IsRequired"] = true; 

	

		

		

		

			$edata["acceptFileTypes"] = ".+$";

	

		$edata["maxNumberOfFiles"] = 1;

	

		

		

		

		

			$edata["HTML5InuptType"] = "number";

	

		$edata["EditParams"] = "";

			

		$edata["controlWidth"] = 200;

	

//	Begin validation

	$edata["validateAs"] = array();

	$edata["validateAs"]["basicValidate"] = array();

	$edata["validateAs"]["customMessages"] = array();

				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");	

						$edata["validateAs"]["basicValidate"][] = "IsRequired";

			

		

	//	End validation

	

		

				

		

	

		

	$fdata["EditFormats"]["edit"] = $edata;

//	End Edit Formats

	

	

	$fdata["isSeparate"] = false;

	

	

	

	

// the field's search options settings

		

			// the default search options list

				$fdata["searchOptionsList"] = array("Equals", "More than", "Less than", "Between");

// the end of search options settings	



	



	

	$tdatadeductions["deductionamount"] = $fdata;

//	deductionreason

//	Custom field settings

	$fdata = array();

	$fdata["Index"] = 6;

	$fdata["strName"] = "deductionreason";

	$fdata["GoodName"] = "deductionreason";

	$fdata["ownerTable"] = "deductions";

	$fdata["Label"] = GetFieldLabel("deductions","deductionreason"); 

	$fdata["FieldType"] = 200;

	

		

		

		

				

		$fdata["bListPage"] = true; 

	

		$fdata["bAddPage"] = true; 

	

		$fdata["bInlineAdd"] = true; 

	

		$fdata["bEditPage"] = true; 

	

		$fdata["bInlineEdit"] = true; 

	

		$fdata["bViewPage"] = true; 

	

		$fdata["bAdvancedSearch"] = true; 

	

		$fdata["bPrinterPage"] = true; 

	

		$fdata["bExportPage"] = true; 

	

		$fdata["strField"] = "deductionreason"; 

	

		$fdata["isSQLExpression"] = true;

	$fdata["FullName"] = "deductionreason";

	

		

		

				$fdata["FieldPermissions"] = true;

	

				$fdata["UploadFolder"] = "files";

		

//  Begin View Formats

	$fdata["ViewFormats"] = array();

	

	$vdata = array("ViewFormat" => "");

	

		

		

		

		

		

		

		

		

		

		

		

		$vdata["NeedEncode"] = true;

	

	$fdata["ViewFormats"]["view"] = $vdata;

//  End View Formats



//	Begin Edit Formats 	

	$fdata["EditFormats"] = array();

	

	$edata = array("EditFormat" => "Lookup wizard");

	

			

	

	

// Begin Lookup settings

		$edata["LookupType"] = 0;

		$edata["autoCompleteFieldsOnEdit"] = 0;

	$edata["autoCompleteFields"] = array();

		$edata["LCType"] = 0;

		

		

		

		$edata["LookupValues"] = array();

	$edata["LookupValues"][] = "Drug Screen";

	$edata["LookupValues"][] = "Time Card";

	$edata["LookupValues"][] = "Uniform";

	$edata["LookupValues"][] = "Bussing";

	$edata["LookupValues"][] = "Equipment";



		

		$edata["SelectSize"] = 1;

		

// End Lookup Settings





		$edata["IsRequired"] = true; 

	

		

		

		

			$edata["acceptFileTypes"] = ".+$";

	

		$edata["maxNumberOfFiles"] = 1;

	

		

		

		

		

		

		

		$edata["controlWidth"] = 200;

	

//	Begin validation

	$edata["validateAs"] = array();

	$edata["validateAs"]["basicValidate"] = array();

	$edata["validateAs"]["customMessages"] = array();

						$edata["validateAs"]["basicValidate"][] = "IsRequired";

			

		

	//	End validation

	

		

				

		

	

		

	$fdata["EditFormats"]["edit"] = $edata;

//	End Edit Formats

	

	

	$fdata["isSeparate"] = false;

	

	

	

	

// the field's search options settings

		$fdata["defaultSearchOption"] = "Equals";

	

			// the default search options list

				$fdata["searchOptionsList"] = array("Contains", "Equals", "Empty");

// the end of search options settings	



	



	

	$tdatadeductions["deductionreason"] = $fdata;

//	ID

//	Custom field settings

	$fdata = array();

	$fdata["Index"] = 7;

	$fdata["strName"] = "ID";

	$fdata["GoodName"] = "ID";

	$fdata["ownerTable"] = "deductions";

	$fdata["Label"] = GetFieldLabel("deductions","ID"); 

	$fdata["FieldType"] = 3;

	

		

		$fdata["AutoInc"] = true;

	

		

				

		$fdata["bListPage"] = true; 

	

		

		

		

		

		$fdata["bViewPage"] = true; 

	

		$fdata["bAdvancedSearch"] = true; 

	

		$fdata["bPrinterPage"] = true; 

	

		

		$fdata["strField"] = "ID"; 

	

		$fdata["isSQLExpression"] = true;

	$fdata["FullName"] = "ID";

	

		

		

				$fdata["FieldPermissions"] = true;

	

				$fdata["UploadFolder"] = "files";

		

//  Begin View Formats

	$fdata["ViewFormats"] = array();

	

	$vdata = array("ViewFormat" => "");

	

		

		

		

		

		

		

		

		

		

		

		

		$vdata["NeedEncode"] = true;

	

	$fdata["ViewFormats"]["view"] = $vdata;

//  End View Formats



//	Begin Edit Formats 	

	$fdata["EditFormats"] = array();

	

	$edata = array("EditFormat" => "Text field");

	

			

	

	





		$edata["IsRequired"] = true; 

	

		

		

		

			$edata["acceptFileTypes"] = ".+$";

	

		$edata["maxNumberOfFiles"] = 1;

	

		

		

		

		

			$edata["HTML5InuptType"] = "number";

	

		$edata["EditParams"] = "";

			

		$edata["controlWidth"] = 200;

	

//	Begin validation

	$edata["validateAs"] = array();

	$edata["validateAs"]["basicValidate"] = array();

	$edata["validateAs"]["customMessages"] = array();

				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");	

						$edata["validateAs"]["basicValidate"][] = "IsRequired";

			

		

	//	End validation

	

		

				

		

	

		

	$fdata["EditFormats"]["edit"] = $edata;

//	End Edit Formats

	

	

	$fdata["isSeparate"] = false;

	

	

	

	

// the field's search options settings

		

			// the default search options list

				$fdata["searchOptionsList"] = array("Equals", "More than", "Less than", "Between");

// the end of search options settings	



	



	

	$tdatadeductions["ID"] = $fdata;

//	duration

//	Custom field settings

	$fdata = array();

	$fdata["Index"] = 8;

	$fdata["strName"] = "duration";

	$fdata["GoodName"] = "duration";

	$fdata["ownerTable"] = "deductions";

	$fdata["Label"] = GetFieldLabel("deductions","duration"); 

	$fdata["FieldType"] = 200;

	

		

		

		

				

		$fdata["bListPage"] = true; 

	

		$fdata["bAddPage"] = true; 

	

		$fdata["bInlineAdd"] = true; 

	

		$fdata["bEditPage"] = true; 

	

		$fdata["bInlineEdit"] = true; 

	

		$fdata["bViewPage"] = true; 

	

		$fdata["bAdvancedSearch"] = true; 

	

		$fdata["bPrinterPage"] = true; 

	

		$fdata["bExportPage"] = true; 

	

		$fdata["strField"] = "duration"; 

	

		$fdata["isSQLExpression"] = true;

	$fdata["FullName"] = "duration";

	

		

		

				$fdata["FieldPermissions"] = true;

	

				$fdata["UploadFolder"] = "files";

		

//  Begin View Formats

	$fdata["ViewFormats"] = array();

	

	$vdata = array("ViewFormat" => "");

	

		

		

		

		

		

		

		

		

		

		

		

		$vdata["NeedEncode"] = true;

	

	$fdata["ViewFormats"]["view"] = $vdata;

//  End View Formats



//	Begin Edit Formats 	

	$fdata["EditFormats"] = array();

	

	$edata = array("EditFormat" => "Lookup wizard");

	

			

	

	

// Begin Lookup settings

		$edata["LookupType"] = 0;

		$edata["autoCompleteFieldsOnEdit"] = 0;

	$edata["autoCompleteFields"] = array();

		$edata["LCType"] = 3;

		

		$edata["HorizontalLookup"] = true;

	

		

		$edata["LookupValues"] = array();

	$edata["LookupValues"][] = "One Time";

	$edata["LookupValues"][] = "Start";

	$edata["LookupValues"][] = "Stop";



		$edata["Multiselect"] = true; 

	

		

// End Lookup Settings





		$edata["IsRequired"] = true; 

	

		

		

		

			$edata["acceptFileTypes"] = ".+$";

	

		$edata["maxNumberOfFiles"] = 1;

	

		

		

		

		

		

		

		$edata["controlWidth"] = 200;

	

//	Begin validation

	$edata["validateAs"] = array();

	$edata["validateAs"]["basicValidate"] = array();

	$edata["validateAs"]["customMessages"] = array();

						$edata["validateAs"]["basicValidate"][] = "IsRequired";

			

		

	//	End validation

	

		

				

		

	

		

	$fdata["EditFormats"]["edit"] = $edata;

//	End Edit Formats

	

	

	$fdata["isSeparate"] = false;

	

	

	

	

// the field's search options settings

		$fdata["defaultSearchOption"] = "Equals";

	

			// the default search options list

				$fdata["searchOptionsList"] = array("Contains", "Equals", "Empty");

// the end of search options settings	



	



	

	$tdatadeductions["duration"] = $fdata;



	

$tables_data["deductions"]=&$tdatadeductions;

$field_labels["deductions"] = &$fieldLabelsdeductions;

$fieldToolTips["deductions"] = &$fieldToolTipsdeductions;

$page_titles["deductions"] = &$pageTitlesdeductions;



// -----------------start  prepare master-details data arrays ------------------------------//

// tables which are detail tables for current table (master)

$detailsTablesData["deductions"] = array();

	

// tables which are master tables for current table (detail)

$masterTablesData["deductions"] = array();





// -----------------end  prepare master-details data arrays ------------------------------//



require_once(getabspath("classes/sql.php"));





















function createSqlQuery_deductions()

{

$proto0=array();

$proto0["m_strHead"] = "SELECT";

$proto0["m_strFieldList"] = "`date`,  branch,  employeeidnumber,  employeename,  deductionamount,  deductionreason,  ID,  duration";

$proto0["m_strFrom"] = "FROM deductions";

$proto0["m_strWhere"] = "";

$proto0["m_strOrderBy"] = "ORDER BY employeeidnumber";

$proto0["m_strTail"] = "";

			$proto0["cipherer"] = null;

$proto1=array();

$proto1["m_sql"] = "";

$proto1["m_uniontype"] = "SQLL_UNKNOWN";

	$obj = new SQLNonParsed(array(

	"m_sql" => ""

));



$proto1["m_column"]=$obj;

$proto1["m_contained"] = array();

$proto1["m_strCase"] = "";

$proto1["m_havingmode"] = false;

$proto1["m_inBrackets"] = false;

$proto1["m_useAlias"] = false;

$obj = new SQLLogicalExpr($proto1);



$proto0["m_where"] = $obj;

$proto3=array();

$proto3["m_sql"] = "";

$proto3["m_uniontype"] = "SQLL_UNKNOWN";

	$obj = new SQLNonParsed(array(

	"m_sql" => ""

));



$proto3["m_column"]=$obj;

$proto3["m_contained"] = array();

$proto3["m_strCase"] = "";

$proto3["m_havingmode"] = false;

$proto3["m_inBrackets"] = false;

$proto3["m_useAlias"] = false;

$obj = new SQLLogicalExpr($proto3);



$proto0["m_having"] = $obj;

$proto0["m_fieldlist"] = array();

						$proto5=array();

			$obj = new SQLField(array(

	"m_strName" => "date",

	"m_strTable" => "deductions",

	"m_srcTableName" => "deductions"

));



$proto5["m_sql"] = "`date`";

$proto5["m_srcTableName"] = "deductions";

$proto5["m_expr"]=$obj;

$proto5["m_alias"] = "";

$obj = new SQLFieldListItem($proto5);



$proto0["m_fieldlist"][]=$obj;

						$proto7=array();

			$obj = new SQLField(array(

	"m_strName" => "branch",

	"m_strTable" => "deductions",

	"m_srcTableName" => "deductions"

));



$proto7["m_sql"] = "branch";

$proto7["m_srcTableName"] = "deductions";

$proto7["m_expr"]=$obj;

$proto7["m_alias"] = "";

$obj = new SQLFieldListItem($proto7);



$proto0["m_fieldlist"][]=$obj;

						$proto9=array();

			$obj = new SQLField(array(

	"m_strName" => "employeeidnumber",

	"m_strTable" => "deductions",

	"m_srcTableName" => "deductions"

));



$proto9["m_sql"] = "employeeidnumber";

$proto9["m_srcTableName"] = "deductions";

$proto9["m_expr"]=$obj;

$proto9["m_alias"] = "";

$obj = new SQLFieldListItem($proto9);



$proto0["m_fieldlist"][]=$obj;

						$proto11=array();

			$obj = new SQLField(array(

	"m_strName" => "employeename",

	"m_strTable" => "deductions",

	"m_srcTableName" => "deductions"

));



$proto11["m_sql"] = "employeename";

$proto11["m_srcTableName"] = "deductions";

$proto11["m_expr"]=$obj;

$proto11["m_alias"] = "";

$obj = new SQLFieldListItem($proto11);



$proto0["m_fieldlist"][]=$obj;

						$proto13=array();

			$obj = new SQLField(array(

	"m_strName" => "deductionamount",

	"m_strTable" => "deductions",

	"m_srcTableName" => "deductions"

));



$proto13["m_sql"] = "deductionamount";

$proto13["m_srcTableName"] = "deductions";

$proto13["m_expr"]=$obj;

$proto13["m_alias"] = "";

$obj = new SQLFieldListItem($proto13);



$proto0["m_fieldlist"][]=$obj;

						$proto15=array();

			$obj = new SQLField(array(

	"m_strName" => "deductionreason",

	"m_strTable" => "deductions",

	"m_srcTableName" => "deductions"

));



$proto15["m_sql"] = "deductionreason";

$proto15["m_srcTableName"] = "deductions";

$proto15["m_expr"]=$obj;

$proto15["m_alias"] = "";

$obj = new SQLFieldListItem($proto15);



$proto0["m_fieldlist"][]=$obj;

						$proto17=array();

			$obj = new SQLField(array(

	"m_strName" => "ID",

	"m_strTable" => "deductions",

	"m_srcTableName" => "deductions"

));



$proto17["m_sql"] = "ID";

$proto17["m_srcTableName"] = "deductions";

$proto17["m_expr"]=$obj;

$proto17["m_alias"] = "";

$obj = new SQLFieldListItem($proto17);



$proto0["m_fieldlist"][]=$obj;

						$proto19=array();

			$obj = new SQLField(array(

	"m_strName" => "duration",

	"m_strTable" => "deductions",

	"m_srcTableName" => "deductions"

));



$proto19["m_sql"] = "duration";

$proto19["m_srcTableName"] = "deductions";

$proto19["m_expr"]=$obj;

$proto19["m_alias"] = "";

$obj = new SQLFieldListItem($proto19);



$proto0["m_fieldlist"][]=$obj;

$proto0["m_fromlist"] = array();

												$proto21=array();

$proto21["m_link"] = "SQLL_MAIN";

			$proto22=array();

$proto22["m_strName"] = "deductions";

$proto22["m_srcTableName"] = "deductions";

$proto22["m_columns"] = array();

$proto22["m_columns"][] = "ID";

$proto22["m_columns"][] = "date";

$proto22["m_columns"][] = "branch";

$proto22["m_columns"][] = "employeeidnumber";

$proto22["m_columns"][] = "employeename";

$proto22["m_columns"][] = "deductionamount";

$proto22["m_columns"][] = "deductionreason";

$proto22["m_columns"][] = "duration";

$obj = new SQLTable($proto22);



$proto21["m_table"] = $obj;

$proto21["m_sql"] = "deductions";

$proto21["m_alias"] = "";

$proto21["m_srcTableName"] = "deductions";

$proto23=array();

$proto23["m_sql"] = "";

$proto23["m_uniontype"] = "SQLL_UNKNOWN";

	$obj = new SQLNonParsed(array(

	"m_sql" => ""

));



$proto23["m_column"]=$obj;

$proto23["m_contained"] = array();

$proto23["m_strCase"] = "";

$proto23["m_havingmode"] = false;

$proto23["m_inBrackets"] = false;

$proto23["m_useAlias"] = false;

$obj = new SQLLogicalExpr($proto23);



$proto21["m_joinon"] = $obj;

$obj = new SQLFromListItem($proto21);



$proto0["m_fromlist"][]=$obj;

$proto0["m_groupby"] = array();

$proto0["m_orderby"] = array();

												$proto25=array();

						$obj = new SQLField(array(

	"m_strName" => "employeeidnumber",

	"m_strTable" => "deductions",

	"m_srcTableName" => "deductions"

));



$proto25["m_column"]=$obj;

$proto25["m_bAsc"] = 1;

$proto25["m_nColumn"] = 0;

$obj = new SQLOrderByItem($proto25);



$proto0["m_orderby"][]=$obj;					

$proto0["m_srcTableName"]="deductions";		

$obj = new SQLQuery($proto0);



	return $obj;

}

$queryData_deductions = createSqlQuery_deductions();





	

								

	

$tdatadeductions[".sqlquery"] = $queryData_deductions;



$tableEvents["deductions"] = new eventsBase;

$tdatadeductions[".hasEvents"] = false;



?>