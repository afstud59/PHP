<?php
require_once(getabspath("classes/cipherer.php"));




$tdataTSI_Deductions_users = array();	
	$tdataTSI_Deductions_users[".truncateText"] = true;
	$tdataTSI_Deductions_users[".NumberOfChars"] = 80; 
	$tdataTSI_Deductions_users[".ShortName"] = "TSI_Deductions_users";
	$tdataTSI_Deductions_users[".OwnerID"] = "";
	$tdataTSI_Deductions_users[".OriginalTable"] = "TSI Deductions_users";

//	field labels
$fieldLabelsTSI_Deductions_users = array();
$fieldToolTipsTSI_Deductions_users = array();
$pageTitlesTSI_Deductions_users = array();

if(mlang_getcurrentlang()=="English")
{
	$fieldLabelsTSI_Deductions_users["English"] = array();
	$fieldToolTipsTSI_Deductions_users["English"] = array();
	$pageTitlesTSI_Deductions_users["English"] = array();
	$fieldLabelsTSI_Deductions_users["English"]["ID"] = "ID";
	$fieldToolTipsTSI_Deductions_users["English"]["ID"] = "";
	$fieldLabelsTSI_Deductions_users["English"]["username"] = "Username";
	$fieldToolTipsTSI_Deductions_users["English"]["username"] = "";
	$fieldLabelsTSI_Deductions_users["English"]["password"] = "Password";
	$fieldToolTipsTSI_Deductions_users["English"]["password"] = "";
	$fieldLabelsTSI_Deductions_users["English"]["email"] = "Email";
	$fieldToolTipsTSI_Deductions_users["English"]["email"] = "";
	$fieldLabelsTSI_Deductions_users["English"]["fullname"] = "Fullname";
	$fieldToolTipsTSI_Deductions_users["English"]["fullname"] = "";
	$fieldLabelsTSI_Deductions_users["English"]["groupid"] = "Groupid";
	$fieldToolTipsTSI_Deductions_users["English"]["groupid"] = "";
	$fieldLabelsTSI_Deductions_users["English"]["active"] = "Active";
	$fieldToolTipsTSI_Deductions_users["English"]["active"] = "";
	if (count($fieldToolTipsTSI_Deductions_users["English"]))
		$tdataTSI_Deductions_users[".isUseToolTips"] = true;
}
if(mlang_getcurrentlang()=="")
{
	$fieldLabelsTSI_Deductions_users[""] = array();
	$fieldToolTipsTSI_Deductions_users[""] = array();
	$pageTitlesTSI_Deductions_users[""] = array();
	if (count($fieldToolTipsTSI_Deductions_users[""]))
		$tdataTSI_Deductions_users[".isUseToolTips"] = true;
}
	
	
	$tdataTSI_Deductions_users[".NCSearch"] = true;



$tdataTSI_Deductions_users[".shortTableName"] = "TSI_Deductions_users";
$tdataTSI_Deductions_users[".nSecOptions"] = 0;
$tdataTSI_Deductions_users[".recsPerRowList"] = 1;
$tdataTSI_Deductions_users[".recsPerRowPrint"] = 1;
$tdataTSI_Deductions_users[".mainTableOwnerID"] = "";
$tdataTSI_Deductions_users[".moveNext"] = 1;
$tdataTSI_Deductions_users[".entityType"] = 0;

$tdataTSI_Deductions_users[".strOriginalTableName"] = "TSI Deductions_users";




$tdataTSI_Deductions_users[".showAddInPopup"] = false;

$tdataTSI_Deductions_users[".showEditInPopup"] = false;

$tdataTSI_Deductions_users[".showViewInPopup"] = false;

//page's base css files names
$popupPagesLayoutNames = array();
$tdataTSI_Deductions_users[".popupPagesLayoutNames"] = $popupPagesLayoutNames;


$tdataTSI_Deductions_users[".fieldsForRegister"] = array();

$tdataTSI_Deductions_users[".listAjax"] = false;

	$tdataTSI_Deductions_users[".audit"] = true;

	$tdataTSI_Deductions_users[".locking"] = false;









$tdataTSI_Deductions_users[".showSimpleSearchOptions"] = false;

// search Saving settings
$tdataTSI_Deductions_users[".searchSaving"] = false;
//

$tdataTSI_Deductions_users[".showSearchPanel"] = true;
		$tdataTSI_Deductions_users[".flexibleSearch"] = true;		

if (isMobile())
	$tdataTSI_Deductions_users[".isUseAjaxSuggest"] = false;
else 
	$tdataTSI_Deductions_users[".isUseAjaxSuggest"] = true;

$tdataTSI_Deductions_users[".rowHighlite"] = true;



$tdataTSI_Deductions_users[".addPageEvents"] = false;

// use timepicker for search panel
$tdataTSI_Deductions_users[".isUseTimeForSearch"] = false;





$tdataTSI_Deductions_users[".allSearchFields"] = array();
$tdataTSI_Deductions_users[".filterFields"] = array();
$tdataTSI_Deductions_users[".requiredSearchFields"] = array();

$tdataTSI_Deductions_users[".allSearchFields"][] = "ID";
	$tdataTSI_Deductions_users[".allSearchFields"][] = "username";
	$tdataTSI_Deductions_users[".allSearchFields"][] = "password";
	$tdataTSI_Deductions_users[".allSearchFields"][] = "email";
	$tdataTSI_Deductions_users[".allSearchFields"][] = "fullname";
	$tdataTSI_Deductions_users[".allSearchFields"][] = "groupid";
	$tdataTSI_Deductions_users[".allSearchFields"][] = "active";
	

$tdataTSI_Deductions_users[".googleLikeFields"] = array();
$tdataTSI_Deductions_users[".googleLikeFields"][] = "ID";
$tdataTSI_Deductions_users[".googleLikeFields"][] = "username";
$tdataTSI_Deductions_users[".googleLikeFields"][] = "password";
$tdataTSI_Deductions_users[".googleLikeFields"][] = "email";
$tdataTSI_Deductions_users[".googleLikeFields"][] = "fullname";
$tdataTSI_Deductions_users[".googleLikeFields"][] = "groupid";
$tdataTSI_Deductions_users[".googleLikeFields"][] = "active";


$tdataTSI_Deductions_users[".advSearchFields"] = array();
$tdataTSI_Deductions_users[".advSearchFields"][] = "ID";
$tdataTSI_Deductions_users[".advSearchFields"][] = "username";
$tdataTSI_Deductions_users[".advSearchFields"][] = "password";
$tdataTSI_Deductions_users[".advSearchFields"][] = "email";
$tdataTSI_Deductions_users[".advSearchFields"][] = "fullname";
$tdataTSI_Deductions_users[".advSearchFields"][] = "groupid";
$tdataTSI_Deductions_users[".advSearchFields"][] = "active";

$tdataTSI_Deductions_users[".tableType"] = "list";

$tdataTSI_Deductions_users[".printerPageOrientation"] = 0;
$tdataTSI_Deductions_users[".nPrinterPageScale"] = 100;

$tdataTSI_Deductions_users[".nPrinterSplitRecords"] = 40;

$tdataTSI_Deductions_users[".nPrinterPDFSplitRecords"] = 40;



$tdataTSI_Deductions_users[".geocodingEnabled"] = false;




	





// view page pdf

// print page pdf


$tdataTSI_Deductions_users[".pageSize"] = 20;

$tdataTSI_Deductions_users[".warnLeavingPages"] = true;



$tstrOrderBy = "";
if(strlen($tstrOrderBy) && strtolower(substr($tstrOrderBy,0,8))!="order by")
	$tstrOrderBy = "order by ".$tstrOrderBy;
$tdataTSI_Deductions_users[".strOrderBy"] = $tstrOrderBy;

$tdataTSI_Deductions_users[".orderindexes"] = array();

$tdataTSI_Deductions_users[".sqlHead"] = "SELECT ID,  	username,  	password,  	email,  	fullname,  	groupid,  	active";
$tdataTSI_Deductions_users[".sqlFrom"] = "FROM `TSI Deductions_users`";
$tdataTSI_Deductions_users[".sqlWhereExpr"] = "";
$tdataTSI_Deductions_users[".sqlTail"] = "";









//fill array of records per page for list and report without group fields
$arrRPP = array();
$arrRPP[] = 10;
$arrRPP[] = 20;
$arrRPP[] = 30;
$arrRPP[] = 50;
$arrRPP[] = 100;
$arrRPP[] = 500;
$arrRPP[] = -1;
$tdataTSI_Deductions_users[".arrRecsPerPage"] = $arrRPP;

//fill array of groups per page for report with group fields
$arrGPP = array();
$arrGPP[] = 1;
$arrGPP[] = 3;
$arrGPP[] = 5;
$arrGPP[] = 10;
$arrGPP[] = 50;
$arrGPP[] = 100;
$arrGPP[] = -1;
$tdataTSI_Deductions_users[".arrGroupsPerPage"] = $arrGPP;

$tdataTSI_Deductions_users[".highlightSearchResults"] = true;

$tableKeysTSI_Deductions_users = array();
$tableKeysTSI_Deductions_users[] = "ID";
$tdataTSI_Deductions_users[".Keys"] = $tableKeysTSI_Deductions_users;

$tdataTSI_Deductions_users[".listFields"] = array();
$tdataTSI_Deductions_users[".listFields"][] = "ID";
$tdataTSI_Deductions_users[".listFields"][] = "username";
$tdataTSI_Deductions_users[".listFields"][] = "password";
$tdataTSI_Deductions_users[".listFields"][] = "email";
$tdataTSI_Deductions_users[".listFields"][] = "fullname";
$tdataTSI_Deductions_users[".listFields"][] = "groupid";
$tdataTSI_Deductions_users[".listFields"][] = "active";

$tdataTSI_Deductions_users[".hideMobileList"] = array();


$tdataTSI_Deductions_users[".viewFields"] = array();
$tdataTSI_Deductions_users[".viewFields"][] = "ID";
$tdataTSI_Deductions_users[".viewFields"][] = "username";
$tdataTSI_Deductions_users[".viewFields"][] = "password";
$tdataTSI_Deductions_users[".viewFields"][] = "email";
$tdataTSI_Deductions_users[".viewFields"][] = "fullname";
$tdataTSI_Deductions_users[".viewFields"][] = "groupid";
$tdataTSI_Deductions_users[".viewFields"][] = "active";

$tdataTSI_Deductions_users[".addFields"] = array();
$tdataTSI_Deductions_users[".addFields"][] = "username";
$tdataTSI_Deductions_users[".addFields"][] = "password";
$tdataTSI_Deductions_users[".addFields"][] = "email";
$tdataTSI_Deductions_users[".addFields"][] = "fullname";
$tdataTSI_Deductions_users[".addFields"][] = "groupid";
$tdataTSI_Deductions_users[".addFields"][] = "active";

$tdataTSI_Deductions_users[".masterListFields"] = array();
$tdataTSI_Deductions_users[".masterListFields"][] = "ID";
$tdataTSI_Deductions_users[".masterListFields"][] = "username";
$tdataTSI_Deductions_users[".masterListFields"][] = "password";
$tdataTSI_Deductions_users[".masterListFields"][] = "email";
$tdataTSI_Deductions_users[".masterListFields"][] = "fullname";
$tdataTSI_Deductions_users[".masterListFields"][] = "groupid";
$tdataTSI_Deductions_users[".masterListFields"][] = "active";

$tdataTSI_Deductions_users[".inlineAddFields"] = array();
$tdataTSI_Deductions_users[".inlineAddFields"][] = "username";
$tdataTSI_Deductions_users[".inlineAddFields"][] = "password";
$tdataTSI_Deductions_users[".inlineAddFields"][] = "email";
$tdataTSI_Deductions_users[".inlineAddFields"][] = "fullname";
$tdataTSI_Deductions_users[".inlineAddFields"][] = "groupid";
$tdataTSI_Deductions_users[".inlineAddFields"][] = "active";

$tdataTSI_Deductions_users[".editFields"] = array();
$tdataTSI_Deductions_users[".editFields"][] = "username";
$tdataTSI_Deductions_users[".editFields"][] = "password";
$tdataTSI_Deductions_users[".editFields"][] = "email";
$tdataTSI_Deductions_users[".editFields"][] = "fullname";
$tdataTSI_Deductions_users[".editFields"][] = "groupid";
$tdataTSI_Deductions_users[".editFields"][] = "active";

$tdataTSI_Deductions_users[".inlineEditFields"] = array();
$tdataTSI_Deductions_users[".inlineEditFields"][] = "username";
$tdataTSI_Deductions_users[".inlineEditFields"][] = "password";
$tdataTSI_Deductions_users[".inlineEditFields"][] = "email";
$tdataTSI_Deductions_users[".inlineEditFields"][] = "fullname";
$tdataTSI_Deductions_users[".inlineEditFields"][] = "groupid";
$tdataTSI_Deductions_users[".inlineEditFields"][] = "active";

$tdataTSI_Deductions_users[".exportFields"] = array();
$tdataTSI_Deductions_users[".exportFields"][] = "ID";
$tdataTSI_Deductions_users[".exportFields"][] = "username";
$tdataTSI_Deductions_users[".exportFields"][] = "password";
$tdataTSI_Deductions_users[".exportFields"][] = "email";
$tdataTSI_Deductions_users[".exportFields"][] = "fullname";
$tdataTSI_Deductions_users[".exportFields"][] = "groupid";
$tdataTSI_Deductions_users[".exportFields"][] = "active";

$tdataTSI_Deductions_users[".importFields"] = array();
$tdataTSI_Deductions_users[".importFields"][] = "ID";
$tdataTSI_Deductions_users[".importFields"][] = "username";
$tdataTSI_Deductions_users[".importFields"][] = "password";
$tdataTSI_Deductions_users[".importFields"][] = "email";
$tdataTSI_Deductions_users[".importFields"][] = "fullname";
$tdataTSI_Deductions_users[".importFields"][] = "groupid";
$tdataTSI_Deductions_users[".importFields"][] = "active";

$tdataTSI_Deductions_users[".printFields"] = array();
$tdataTSI_Deductions_users[".printFields"][] = "ID";
$tdataTSI_Deductions_users[".printFields"][] = "username";
$tdataTSI_Deductions_users[".printFields"][] = "password";
$tdataTSI_Deductions_users[".printFields"][] = "email";
$tdataTSI_Deductions_users[".printFields"][] = "fullname";
$tdataTSI_Deductions_users[".printFields"][] = "groupid";
$tdataTSI_Deductions_users[".printFields"][] = "active";

//	ID
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 1;
	$fdata["strName"] = "ID";
	$fdata["GoodName"] = "ID";
	$fdata["ownerTable"] = "TSI Deductions_users";
	$fdata["Label"] = GetFieldLabel("TSI_Deductions_users","ID"); 
	$fdata["FieldType"] = 3;
	
		
		$fdata["AutoInc"] = true;
	
		
				
		$fdata["bListPage"] = true; 
	
		
		
		
		
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "ID"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "ID";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text field");
	
			
	
	


		$edata["IsRequired"] = true; 
	
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
			$edata["HTML5InuptType"] = "number";
	
		$edata["EditParams"] = "";
			
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");	
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
			
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the default search options list
				$fdata["searchOptionsList"] = array("Equals", "More than", "Less than", "Between");
// the end of search options settings	

	

	
	$tdataTSI_Deductions_users["ID"] = $fdata;
//	username
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 2;
	$fdata["strName"] = "username";
	$fdata["GoodName"] = "username";
	$fdata["ownerTable"] = "TSI Deductions_users";
	$fdata["Label"] = GetFieldLabel("TSI_Deductions_users","username"); 
	$fdata["FieldType"] = 200;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		$fdata["bInlineAdd"] = true; 
	
		$fdata["bEditPage"] = true; 
	
		$fdata["bInlineEdit"] = true; 
	
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "username"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "username";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text field");
	
			
	
	


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
			$edata["HTML5InuptType"] = "text";
	
		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=300";
	
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Empty");
// the end of search options settings	

	

	
	$tdataTSI_Deductions_users["username"] = $fdata;
//	password
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 3;
	$fdata["strName"] = "password";
	$fdata["GoodName"] = "password";
	$fdata["ownerTable"] = "TSI Deductions_users";
	$fdata["Label"] = GetFieldLabel("TSI_Deductions_users","password"); 
	$fdata["FieldType"] = 200;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		$fdata["bInlineAdd"] = true; 
	
		$fdata["bEditPage"] = true; 
	
		$fdata["bInlineEdit"] = true; 
	
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "password"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "password";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Password");
	
			
	
	


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
		
		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=300";
	
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Empty");
// the end of search options settings	

	

	
	$tdataTSI_Deductions_users["password"] = $fdata;
//	email
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 4;
	$fdata["strName"] = "email";
	$fdata["GoodName"] = "email";
	$fdata["ownerTable"] = "TSI Deductions_users";
	$fdata["Label"] = GetFieldLabel("TSI_Deductions_users","email"); 
	$fdata["FieldType"] = 200;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		$fdata["bInlineAdd"] = true; 
	
		$fdata["bEditPage"] = true; 
	
		$fdata["bInlineEdit"] = true; 
	
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "email"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "email";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text field");
	
			
	
	


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
			$edata["HTML5InuptType"] = "email";
	
		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=300";
	
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Empty");
// the end of search options settings	

	

	
	$tdataTSI_Deductions_users["email"] = $fdata;
//	fullname
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 5;
	$fdata["strName"] = "fullname";
	$fdata["GoodName"] = "fullname";
	$fdata["ownerTable"] = "TSI Deductions_users";
	$fdata["Label"] = GetFieldLabel("TSI_Deductions_users","fullname"); 
	$fdata["FieldType"] = 200;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		$fdata["bInlineAdd"] = true; 
	
		$fdata["bEditPage"] = true; 
	
		$fdata["bInlineEdit"] = true; 
	
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "fullname"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "fullname";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text field");
	
			
	
	


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
			$edata["HTML5InuptType"] = "text";
	
		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=300";
	
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Empty");
// the end of search options settings	

	

	
	$tdataTSI_Deductions_users["fullname"] = $fdata;
//	groupid
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 6;
	$fdata["strName"] = "groupid";
	$fdata["GoodName"] = "groupid";
	$fdata["ownerTable"] = "TSI Deductions_users";
	$fdata["Label"] = GetFieldLabel("TSI_Deductions_users","groupid"); 
	$fdata["FieldType"] = 200;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		$fdata["bInlineAdd"] = true; 
	
		$fdata["bEditPage"] = true; 
	
		$fdata["bInlineEdit"] = true; 
	
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "groupid"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "groupid";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text field");
	
			
	
	


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
			$edata["HTML5InuptType"] = "text";
	
		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=300";
	
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
		
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Empty");
// the end of search options settings	

	

	
	$tdataTSI_Deductions_users["groupid"] = $fdata;
//	active
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 7;
	$fdata["strName"] = "active";
	$fdata["GoodName"] = "active";
	$fdata["ownerTable"] = "TSI Deductions_users";
	$fdata["Label"] = GetFieldLabel("TSI_Deductions_users","active"); 
	$fdata["FieldType"] = 3;
	
		
		
		
				
		$fdata["bListPage"] = true; 
	
		$fdata["bAddPage"] = true; 
	
		$fdata["bInlineAdd"] = true; 
	
		$fdata["bEditPage"] = true; 
	
		$fdata["bInlineEdit"] = true; 
	
		$fdata["bViewPage"] = true; 
	
		$fdata["bAdvancedSearch"] = true; 
	
		$fdata["bPrinterPage"] = true; 
	
		$fdata["bExportPage"] = true; 
	
		$fdata["strField"] = "active"; 
	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "active";
	
		
		
				$fdata["FieldPermissions"] = true;
	
				$fdata["UploadFolder"] = "files";
		
//  Begin View Formats
	$fdata["ViewFormats"] = array();
	
	$vdata = array("ViewFormat" => "");
	
		
		
		
		
		
		
		
		
		
		
		
		$vdata["NeedEncode"] = true;
	
	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats 	
	$fdata["EditFormats"] = array();
	
	$edata = array("EditFormat" => "Text field");
	
			
	
	


		
		
		
		
			$edata["acceptFileTypes"] = ".+$";
	
		$edata["maxNumberOfFiles"] = 1;
	
		
		
		
		
			$edata["HTML5InuptType"] = "number";
	
		$edata["EditParams"] = "";
			
		$edata["controlWidth"] = 200;
	
//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");	
								
		
	//	End validation
	
		
				
		
	
		
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats
	
	
	$fdata["isSeparate"] = false;
	
	
	
	
// the field's search options settings
		
			// the default search options list
				$fdata["searchOptionsList"] = array("Equals", "More than", "Less than", "Between");
// the end of search options settings	

	

	
	$tdataTSI_Deductions_users["active"] = $fdata;

	
$tables_data["TSI Deductions_users"]=&$tdataTSI_Deductions_users;
$field_labels["TSI_Deductions_users"] = &$fieldLabelsTSI_Deductions_users;
$fieldToolTips["TSI Deductions_users"] = &$fieldToolTipsTSI_Deductions_users;
$page_titles["TSI_Deductions_users"] = &$pageTitlesTSI_Deductions_users;

// -----------------start  prepare master-details data arrays ------------------------------//
// tables which are detail tables for current table (master)
$detailsTablesData["TSI Deductions_users"] = array();
	
// tables which are master tables for current table (detail)
$masterTablesData["TSI Deductions_users"] = array();


// -----------------end  prepare master-details data arrays ------------------------------//

require_once(getabspath("classes/sql.php"));










function createSqlQuery_TSI_Deductions_users()
{
$proto0=array();
$proto0["m_strHead"] = "SELECT";
$proto0["m_strFieldList"] = "ID,  	username,  	password,  	email,  	fullname,  	groupid,  	active";
$proto0["m_strFrom"] = "FROM `TSI Deductions_users`";
$proto0["m_strWhere"] = "";
$proto0["m_strOrderBy"] = "";
$proto0["m_strTail"] = "";
			$proto0["cipherer"] = null;
$proto1=array();
$proto1["m_sql"] = "";
$proto1["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto1["m_column"]=$obj;
$proto1["m_contained"] = array();
$proto1["m_strCase"] = "";
$proto1["m_havingmode"] = false;
$proto1["m_inBrackets"] = false;
$proto1["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto1);

$proto0["m_where"] = $obj;
$proto3=array();
$proto3["m_sql"] = "";
$proto3["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto3["m_column"]=$obj;
$proto3["m_contained"] = array();
$proto3["m_strCase"] = "";
$proto3["m_havingmode"] = false;
$proto3["m_inBrackets"] = false;
$proto3["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto3);

$proto0["m_having"] = $obj;
$proto0["m_fieldlist"] = array();
						$proto5=array();
			$obj = new SQLField(array(
	"m_strName" => "ID",
	"m_strTable" => "TSI Deductions_users",
	"m_srcTableName" => "TSI Deductions_users"
));

$proto5["m_sql"] = "ID";
$proto5["m_srcTableName"] = "TSI Deductions_users";
$proto5["m_expr"]=$obj;
$proto5["m_alias"] = "";
$obj = new SQLFieldListItem($proto5);

$proto0["m_fieldlist"][]=$obj;
						$proto7=array();
			$obj = new SQLField(array(
	"m_strName" => "username",
	"m_strTable" => "TSI Deductions_users",
	"m_srcTableName" => "TSI Deductions_users"
));

$proto7["m_sql"] = "username";
$proto7["m_srcTableName"] = "TSI Deductions_users";
$proto7["m_expr"]=$obj;
$proto7["m_alias"] = "";
$obj = new SQLFieldListItem($proto7);

$proto0["m_fieldlist"][]=$obj;
						$proto9=array();
			$obj = new SQLField(array(
	"m_strName" => "password",
	"m_strTable" => "TSI Deductions_users",
	"m_srcTableName" => "TSI Deductions_users"
));

$proto9["m_sql"] = "password";
$proto9["m_srcTableName"] = "TSI Deductions_users";
$proto9["m_expr"]=$obj;
$proto9["m_alias"] = "";
$obj = new SQLFieldListItem($proto9);

$proto0["m_fieldlist"][]=$obj;
						$proto11=array();
			$obj = new SQLField(array(
	"m_strName" => "email",
	"m_strTable" => "TSI Deductions_users",
	"m_srcTableName" => "TSI Deductions_users"
));

$proto11["m_sql"] = "email";
$proto11["m_srcTableName"] = "TSI Deductions_users";
$proto11["m_expr"]=$obj;
$proto11["m_alias"] = "";
$obj = new SQLFieldListItem($proto11);

$proto0["m_fieldlist"][]=$obj;
						$proto13=array();
			$obj = new SQLField(array(
	"m_strName" => "fullname",
	"m_strTable" => "TSI Deductions_users",
	"m_srcTableName" => "TSI Deductions_users"
));

$proto13["m_sql"] = "fullname";
$proto13["m_srcTableName"] = "TSI Deductions_users";
$proto13["m_expr"]=$obj;
$proto13["m_alias"] = "";
$obj = new SQLFieldListItem($proto13);

$proto0["m_fieldlist"][]=$obj;
						$proto15=array();
			$obj = new SQLField(array(
	"m_strName" => "groupid",
	"m_strTable" => "TSI Deductions_users",
	"m_srcTableName" => "TSI Deductions_users"
));

$proto15["m_sql"] = "groupid";
$proto15["m_srcTableName"] = "TSI Deductions_users";
$proto15["m_expr"]=$obj;
$proto15["m_alias"] = "";
$obj = new SQLFieldListItem($proto15);

$proto0["m_fieldlist"][]=$obj;
						$proto17=array();
			$obj = new SQLField(array(
	"m_strName" => "active",
	"m_strTable" => "TSI Deductions_users",
	"m_srcTableName" => "TSI Deductions_users"
));

$proto17["m_sql"] = "active";
$proto17["m_srcTableName"] = "TSI Deductions_users";
$proto17["m_expr"]=$obj;
$proto17["m_alias"] = "";
$obj = new SQLFieldListItem($proto17);

$proto0["m_fieldlist"][]=$obj;
$proto0["m_fromlist"] = array();
												$proto19=array();
$proto19["m_link"] = "SQLL_MAIN";
			$proto20=array();
$proto20["m_strName"] = "TSI Deductions_users";
$proto20["m_srcTableName"] = "TSI Deductions_users";
$proto20["m_columns"] = array();
$proto20["m_columns"][] = "ID";
$proto20["m_columns"][] = "username";
$proto20["m_columns"][] = "password";
$proto20["m_columns"][] = "email";
$proto20["m_columns"][] = "fullname";
$proto20["m_columns"][] = "groupid";
$proto20["m_columns"][] = "active";
$obj = new SQLTable($proto20);

$proto19["m_table"] = $obj;
$proto19["m_sql"] = "`TSI Deductions_users`";
$proto19["m_alias"] = "";
$proto19["m_srcTableName"] = "TSI Deductions_users";
$proto21=array();
$proto21["m_sql"] = "";
$proto21["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto21["m_column"]=$obj;
$proto21["m_contained"] = array();
$proto21["m_strCase"] = "";
$proto21["m_havingmode"] = false;
$proto21["m_inBrackets"] = false;
$proto21["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto21);

$proto19["m_joinon"] = $obj;
$obj = new SQLFromListItem($proto19);

$proto0["m_fromlist"][]=$obj;
$proto0["m_groupby"] = array();
$proto0["m_orderby"] = array();
$proto0["m_srcTableName"]="TSI Deductions_users";		
$obj = new SQLQuery($proto0);

	return $obj;
}
$queryData_TSI_Deductions_users = createSqlQuery_TSI_Deductions_users();


	
							
	
$tdataTSI_Deductions_users[".sqlquery"] = $queryData_TSI_Deductions_users;

$tableEvents["TSI Deductions_users"] = new eventsBase;
$tdataTSI_Deductions_users[".hasEvents"] = false;

?>